Mii 推しライブ V6（販売向けロック型）

内容:
- 横画面固定
- 左70% 配信画面 / 右30% UI
- 公式キャラ1人固定
- 背景固定
- 初期立ち絵 + 表情差分 + 上限解放2段階
- 画像変更ボタンなし（購入ユーザーはアプリ内で変更不可）
- 投げ銭: 初期 240円 / 1000円、累計で 5000円 / 10000円 / 50000円 解放

差し替えしたい制作者向けファイル:
app/src/main/res/drawable-nodpi/
- bg_stream.png        配信背景
- stage1_idle.png      初期立ち絵
- stage1_blush.png     初期表情差分
- stage2_idle.png      1段階解放立ち絵
- stage3_idle.png      2段階解放立ち絵

販売用に更新するとき:
1. 上記画像を同じ名前で差し替える
2. GitHubにアップロード
3. Actions → Build Android APK → Run workflow
4. ArtifactsからAPKをダウンロード

注意:
普通のユーザーはアプリ内から画像変更できません。
ただしAPK解析・改造まで完全に防ぐものではありません。
