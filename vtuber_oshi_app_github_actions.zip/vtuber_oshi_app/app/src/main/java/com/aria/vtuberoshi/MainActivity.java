package com.aria.vtuberoshi;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.NumberFormat;
import java.util.*;

public class MainActivity extends Activity {
    int total = 0;
    int affection = 0;
    TextView reaction, totalText, affectionText, chatText;
    final Random random = new Random();
    final String[] chats = {"こんこん〜！", "九尾かわいい！", "背景きれい", "今日も癒される〜", "投げ銭タイムだ！", "紫月ちゃん最高！"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(35, 17, 55));
        root.setPadding(16, 16, 16, 16);
        setContentView(root);

        TextView title = label("九尾VTuber 推し活ライブ", 24, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout stage = new FrameLayout(this);
        ImageView img = new ImageView(this);
        img.setImageResource(getResources().getIdentifier("vtuber_sheet", "drawable", getPackageName()));
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        stage.addView(img, new FrameLayout.LayoutParams(-1, -1));
        TextView live = label("● LIVE", 16, true);
        live.setTextColor(Color.rgb(255,210,245));
        live.setPadding(18, 10, 18, 10);
        stage.addView(live, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT));
        root.addView(stage, new LinearLayout.LayoutParams(-1, 0, 1.2f));

        reaction = label("紫月こんこん：今日も会いに来てくれてありがとう♡", 18, true);
        reaction.setGravity(Gravity.CENTER);
        reaction.setPadding(8, 14, 8, 14);
        root.addView(reaction, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout status = new LinearLayout(this);
        status.setOrientation(LinearLayout.HORIZONTAL);
        totalText = label("合計: ¥0", 16, true);
        affectionText = label("好感度: 0", 16, true);
        status.addView(totalText, new LinearLayout.LayoutParams(0, -2, 1));
        status.addView(affectionText, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(status);

        chatText = label("コメント\n・こんこん〜！\n・九尾かわいい！", 14, false);
        chatText.setBackgroundColor(Color.argb(120, 255, 255, 255));
        chatText.setTextColor(Color.rgb(40, 20, 60));
        chatText.setPadding(16, 10, 16, 10);
        root.addView(chatText, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        int[] amounts = {100, 500, 1000, 5000, 10000};
        for (int a : amounts) {
            Button btn = new Button(this);
            btn.setText("¥" + NumberFormat.getNumberInstance(Locale.JAPAN).format(a));
            btn.setOnClickListener(v -> donate(a));
            buttons.addView(btn, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(buttons, new LinearLayout.LayoutParams(-1, -2));
    }

    TextView label(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(Color.WHITE);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    void donate(int amount) {
        total += amount;
        affection += Math.max(1, amount / 500);
        totalText.setText("合計: ¥" + NumberFormat.getNumberInstance(Locale.JAPAN).format(total));
        affectionText.setText("好感度: " + affection);
        if (amount >= 10000) reaction.setText("紫月こんこん：えっ、すごい…！一生忘れないよっ♡");
        else if (amount >= 5000) reaction.setText("紫月こんこん：大きな応援ありがとう！尻尾ぶんぶんしちゃう！");
        else if (amount >= 1000) reaction.setText("紫月こんこん：ナイス投げ銭！今日も推してくれてうれしいな♪");
        else reaction.setText("紫月こんこん：ありがとう、だいすき〜！");
        chatText.setText("コメント\n・" + chats[random.nextInt(chats.length)] + "\n・投げ銭きたー！\n・紫月ちゃん反応かわいい！");
    }
}
