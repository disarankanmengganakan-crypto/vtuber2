Mii 推しライブ V7（販売向けロック型）

更新内容:
- 投げ銭ボタンが潰れにくいように右側UIをコンパクト化
- 金額ボタンを2列グリッド配置に変更
- 送ってもらったイラストをアプリアイコンとして実装
- キャラクター1種類固定、画像変更ボタンなし
- 横画面固定、左70%配信画面 / 右30%操作UI

APK化:
1. このzipをGitHubにアップロード
2. Actions → Build Android APK → Run workflow
3. 成功後、ArtifactsからAPKをダウンロード

画像差し替え（制作者向け）:
app/src/main/res/drawable-nodpi/
- bg_stream.png       配信背景
- stage1_idle.png     初期立ち絵
- stage1_blush.png    初期表情差分
- stage2_idle.png     1段階解放
- stage3_idle.png     2段階解放

アイコン:
app/src/main/res/mipmap-*/ic_launcher.png
