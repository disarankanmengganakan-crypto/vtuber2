package com.kokon.vtuberlocked;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    int total = 0, affection = 0, stage = 1, expr = 0;
    ImageView charView, bgView;
    TextView line, totalView, affView, unlockView, commentView, titleView, hintView;
    GridLayout moneyGrid;
    boolean inStream = false;
    int[] amounts = {240, 1000, 5000, 10000, 50000};
    boolean[] unlocked = {true, true, false, false, false};
    String[] comments = {"Miiちゃん今日もかわいい！", "配信部屋めっちゃ似合ってる", "応援してるよ！"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        showTitle();
    }

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView tv(String s, int sp, int c, int style) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(c); v.setTypeface(Typeface.DEFAULT, style);
        v.setPadding(dp(6), dp(4), dp(6), dp(4)); return v;
    }

    GradientDrawable round(int color, int strokeColor, int strokeWidth, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        if (strokeWidth > 0) g.setStroke(dp(strokeWidth), strokeColor);
        return g;
    }

    public void showTitle() {
        inStream = false;
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(12, 0, 24));

        ImageView titleBg = new ImageView(this);
        titleBg.setImageResource(getResources().getIdentifier("title_bg", "drawable", getPackageName()));
        titleBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(titleBg, new FrameLayout.LayoutParams(-1, -1));

        View shade = new View(this);
        GradientDrawable sg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x77000000, 0x11000000, 0xaa080012});
        shade.setBackground(sg);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("title_logo", "drawable", getPackageName()));
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(dp(520), dp(170));
        logoLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        logoLp.topMargin = dp(8);
        root.addView(logo, logoLp);
        pulseLoop(logo);

        TextView tapText = tv("キャラクターをタップして配信へ", 18, Color.WHITE, Typeface.BOLD);
        tapText.setGravity(Gravity.CENTER);
        tapText.setShadowLayer(dp(8), 0, 0, Color.BLACK);
        tapText.setBackground(round(0x77000000, 0x66ff77bb, 1, 20));
        FrameLayout.LayoutParams tapLp = new FrameLayout.LayoutParams(dp(360), dp(46));
        tapLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        tapLp.bottomMargin = dp(16);
        root.addView(tapText, tapLp);

        String[] labels = {"Mii 配信へ", "準備中", "準備中", "準備中"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView hot = tv(labels[i], 14, Color.WHITE, Typeface.BOLD);
            hot.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            hot.setShadowLayer(dp(5), 0, 0, Color.BLACK);
            hot.setBackgroundColor(Color.TRANSPARENT);
            FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(0, -1);
            hp.width = getResources().getDisplayMetrics().widthPixels / 4;
            hp.leftMargin = hp.width * i;
            root.addView(hot, hp);
            hot.setOnClickListener(v -> {
                if (idx == 0) { buildStream(); updateAll(); startFloat(); }
                else { showPreparing(idx); }
            });
        }

        setContentView(root);
    }

    void showPreparing(int idx) {
        Toast.makeText(this, "キャラ" + (idx + 1) + "は準備中です", Toast.LENGTH_SHORT).show();
    }

    public void buildStream() {
        inStream = true;
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(20, 0, 28));

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.HORIZONTAL);
        main.setPadding(dp(10), dp(8), dp(10), dp(8));
        root.addView(main, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout live = new FrameLayout(this);
        main.addView(live, new LinearLayout.LayoutParams(0, -1, 7));
        bgView = new ImageView(this);
        bgView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bgView.setImageResource(getResources().getIdentifier("bg_stream", "drawable", getPackageName()));
        live.addView(bgView, new FrameLayout.LayoutParams(-1, -1));

        charView = new ImageView(this);
        charView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -1);
        cp.gravity = Gravity.CENTER;
        live.addView(charView, cp);
        live.setOnClickListener(v -> { expr = (expr + 1) % 2; reactTap(); });

        TextView liveTxt = tv("● LIVE", 25, Color.WHITE, Typeface.BOLD);
        liveTxt.setShadowLayer(dp(8), 0, 0, Color.BLACK);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(16); lp.topMargin = dp(10);
        live.addView(liveTxt, lp);

        TextView back = tv("← TITLE", 13, Color.WHITE, Typeface.BOLD);
        back.setShadowLayer(dp(6),0,0,Color.BLACK);
        back.setBackground(round(0x66000000, 0x66ffffff, 1, 14));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2);
        bp.gravity = Gravity.TOP | Gravity.RIGHT;
        bp.topMargin = dp(10); bp.rightMargin = dp(10);
        live.addView(back, bp);
        back.setOnClickListener(v -> showTitle());

        TextView tapHint = tv("TAPで表情変更", 13, 0xffffe6ef, Typeface.BOLD);
        tapHint.setShadowLayer(dp(6),0,0,Color.BLACK);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2);
        hp.leftMargin = dp(16); hp.gravity = Gravity.BOTTOM | Gravity.LEFT; hp.bottomMargin = dp(12);
        live.addView(tapHint, hp);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(6), dp(4), dp(6));
        main.addView(panel, new LinearLayout.LayoutParams(0, -1, 3));

        titleView = tv("Mii 推しライブ", 20, Color.WHITE, Typeface.BOLD);
        titleView.setGravity(Gravity.CENTER);
        panel.addView(titleView, new LinearLayout.LayoutParams(-1, -2));

        line = tv("Mii：今日も会いに来てくれてありがとう！", 16, Color.WHITE, Typeface.BOLD);
        line.setGravity(Gravity.CENTER);
        line.setBackground(round(0x33100020, 0x55ff5b79, 1, 18));
        panel.addView(line, new LinearLayout.LayoutParams(-1, 0, 1.2f));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.VERTICAL);
        stats.setPadding(dp(2), dp(2), dp(2), dp(2));
        totalView = tv("", 15, Color.WHITE, Typeface.BOLD);
        affView = tv("", 15, Color.WHITE, Typeface.BOLD);
        unlockView = tv("", 11, 0xffffd6e2, Typeface.BOLD);
        stats.addView(totalView); stats.addView(affView); stats.addView(unlockView);
        panel.addView(stats, new LinearLayout.LayoutParams(-1, 0, 1.0f));

        commentView = tv("", 12, 0xff26142f, Typeface.NORMAL);
        commentView.setBackground(round(0xeef2e8f5, 0, 0, 16));
        panel.addView(commentView, new LinearLayout.LayoutParams(-1, 0, 1.15f));

        hintView = tv("投げ銭", 13, 0xffffd6e2, Typeface.BOLD);
        hintView.setGravity(Gravity.CENTER);
        panel.addView(hintView, new LinearLayout.LayoutParams(-1, -2));

        moneyGrid = new GridLayout(this);
        moneyGrid.setColumnCount(2);
        moneyGrid.setRowCount(3);
        moneyGrid.setPadding(0, dp(2), 0, dp(2));
        panel.addView(moneyGrid, new LinearLayout.LayoutParams(-1, 0, 1.45f));

        Button reset = new Button(this);
        reset.setText("RESET"); reset.setTextSize(11); reset.setAllCaps(false);
        reset.setPadding(dp(4), 0, dp(4), 0);
        reset.setOnClickListener(v -> { total=0; affection=0; stage=1; expr=0; Arrays.fill(unlocked,false); unlocked[0]=unlocked[1]=true; updateAll(); });
        panel.addView(reset, new LinearLayout.LayoutParams(-1, dp(34)));

        setContentView(root);
    }

    void makeButtons() {
        moneyGrid.removeAllViews();
        for (int i = 0; i < amounts.length; i++) {
            final int a = amounts[i];
            Button bt = new Button(this);
            bt.setText(unlocked[i] ? "￥" + NumberFormat.getNumberInstance().format(a) : "🔒￥" + NumberFormat.getNumberInstance().format(a));
            bt.setEnabled(unlocked[i]);
            bt.setTextSize(11);
            bt.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            bt.setAllCaps(false);
            bt.setSingleLine(true);
            bt.setPadding(dp(2), 0, dp(2), 0);
            bt.setBackground(round(unlocked[i] ? 0xfff7f0fb : 0xff8b7f90, unlocked[i] ? 0xffff5b79 : 0xff5a5060, 2, 16));
            bt.setTextColor(unlocked[i] ? 0xff26142f : 0xff342b38);
            bt.setOnClickListener(v -> donate(a));
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0; gp.height = dp(44);
            gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            gp.setMargins(dp(3), dp(3), dp(3), dp(3));
            moneyGrid.addView(bt, gp);
        }
    }

    void donate(int a) {
        total += a; affection += Math.max(1, a / 120);
        line.setText("Mii：￥" + NumberFormat.getNumberInstance().format(a) + "ありがとう！もっと頑張るね！");
        addComment("あなた：￥" + NumberFormat.getNumberInstance().format(a) + " 応援するよ！");
        checkUnlock(); pulse(charView); updateAll();
    }

    void checkUnlock() {
        int old = stage;
        if (total >= 10000) { unlocked[3] = true; stage = 3; }
        else if (total >= 5000) { unlocked[2] = true; stage = 2; }
        if (total >= 50000) unlocked[4] = true;
        if (stage > old) unlockEffect();
    }

    void unlockEffect() {
        line.setText(stage == 2 ? "Mii：新しい姿、見せちゃうね…！" : "Mii：ここまで応援してくれたんだね…♡");
        final TextView flash = tv("STAGE UP!", 40, 0xffffd1e6, Typeface.BOLD);
        flash.setGravity(Gravity.CENTER); flash.setShadowLayer(dp(12),0,0,0xffff2d80);
        addContentView(flash, new ViewGroup.LayoutParams(-1, -1));
        AlphaAnimation aa = new AlphaAnimation(1, 0); aa.setDuration(1500);
        aa.setAnimationListener(new Animation.AnimationListener(){ public void onAnimationStart(Animation a){} public void onAnimationRepeat(Animation a){} public void onAnimationEnd(Animation a){ ((ViewGroup)flash.getParent()).removeView(flash); }});
        flash.startAnimation(aa);
    }

    void reactTap() {
        if (stage == 1) line.setText(expr == 1 ? "Mii：ふふ、見つめすぎだよ…？" : "Mii：今日も会いに来てくれてありがとう！");
        else line.setText(stage == 2 ? "Mii：この姿、どうかな…？" : "Mii：もっと近くで見ててね");
        updateImage(); pulse(charView);
    }

    void updateAll() {
        checkUnlock(); updateImage(); makeButtons();
        totalView.setText("累計：￥" + NumberFormat.getNumberInstance().format(total));
        affView.setText("好感度：" + affection);
        unlockView.setText("解放：￥240 / ￥1,000" + (unlocked[2]?" / ￥5,000":" / 🔒￥5,000") + (unlocked[3]?" / ￥10,000":" / 🔒￥10,000") + (unlocked[4]?" / ￥50,000":" / 🔒￥50,000"));
        commentView.setText("コメント\n・" + String.join("\n・", comments));
    }

    void updateImage() {
        String name = "stage1_idle";
        if (stage == 1 && expr == 1) name = "stage1_blush";
        else if (stage == 2) name = "stage2_idle";
        else if (stage >= 3) name = "stage3_idle";
        charView.setImageResource(getResources().getIdentifier(name, "drawable", getPackageName()));
    }

    void addComment(String s) {
        ArrayList<String> list = new ArrayList<>(); list.add(s);
        for (String c : comments) list.add(c);
        while (list.size() > 4) list.remove(list.size() - 1);
        comments = list.toArray(new String[0]);
    }

    void pulse(View v) {
        ScaleAnimation s = new ScaleAnimation(1f,1.035f,1f,1.035f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f);
        s.setDuration(170); s.setRepeatCount(1); s.setRepeatMode(Animation.REVERSE); v.startAnimation(s);
    }

    void pulseLoop(View v) {
        ScaleAnimation s = new ScaleAnimation(1f,1.035f,1f,1.035f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f);
        s.setDuration(1150); s.setRepeatCount(Animation.INFINITE); s.setRepeatMode(Animation.REVERSE); v.startAnimation(s);
    }

    void startFloat() {
        TranslateAnimation t = new TranslateAnimation(0,0,-5,5);
        t.setDuration(1800); t.setRepeatCount(Animation.INFINITE); t.setRepeatMode(Animation.REVERSE); charView.startAnimation(t);
    }

    @Override public void onBackPressed() {
        if (inStream) showTitle(); else super.onBackPressed();
    }
}
