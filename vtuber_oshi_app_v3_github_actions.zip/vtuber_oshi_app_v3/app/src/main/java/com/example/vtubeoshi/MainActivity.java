package com.example.vtubeoshi;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.graphics.*;
import android.content.Context;
import android.content.res.Resources;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(new OshiView(this)); }

    static class OshiView extends View {
        Bitmap sheet;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Random rnd = new Random();
        long start = System.currentTimeMillis();
        long lastDonate = 0;
        int total = 162700, affection = 327, combo = 0, mood = 0;
        String line = "紫月こんこん：今日も会いに来てくれてありがと！";
        ArrayList<Particle> particles = new ArrayList<>();
        ArrayList<String> comments = new ArrayList<>();
        int[] amounts = {100,500,1000,5000,10000};
        RectF[] buttons = new RectF[5];
        String[] names = {"きつね好き", "こんこん侍", "紫月推し", "九尾の民", "ないすぽ！"};
        String[] small = {"えへへ、応援ありがと！", "その気持ち、ちゃんと届いたよ！", "しっぽふりふりしちゃう！"};
        String[] middle = {"わ、うれしい！狐火でお返しするね！", "紫月、もっと頑張っちゃう！", "ありがと！好感度ぐんぐん上がるよ！"};
        String[] big = {"わわっ！？大きな応援ありがとう！", "紫の狐火、全開でお礼するね！", "今日いちばん幸せかも……！"};
        String[] idleComments = {"・しっぽ揺れてる？", "・こんこん〜", "・今日もかわいい", "・紫月ちゃん見に来た", "・背景きれい"};

        OshiView(Context c){
            super(c);
            setFocusable(true);
            setBackgroundColor(Color.rgb(31,10,48));
            sheet = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("vtuber_sheet","drawable",c.getPackageName()));
            comments.add("・背景きれい"); comments.add("・紫月ちゃんかわいい！"); comments.add("・まずは挨拶こんこん");
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            float t=(System.currentTimeMillis()-start)/1000f;
            float top = dp(10);
            float titleY = top + dp(34);
            float imgTop = top + dp(52);
            float btnH = dp(56);
            float bottomPad = dp(10);
            float btnTop = h - btnH - bottomPad;
            float infoTop = btnTop - dp(245);
            float imgBottom = Math.max(imgTop + dp(220), infoTop - dp(15));

            drawBackground(c,w,h,t);
            drawTitle(c,w,titleY);
            drawStreamImage(c,w,imgTop,imgBottom,t);
            drawIdleEffects(c,w,imgTop,imgBottom,t);
            drawParticles(c, t);
            drawTextPanel(c,w,infoTop,btnTop,t);
            drawButtons(c,w,btnTop,btnH,t);
            postInvalidateOnAnimation();
        }

        void drawBackground(Canvas c,float w,float h,float t){
            LinearGradient g = new LinearGradient(0,0,0,h, Color.rgb(42,12,67), Color.rgb(20,5,35), Shader.TileMode.CLAMP);
            p.setShader(g); c.drawRect(0,0,w,h,p); p.setShader(null);
            p.setColor(Color.argb(40,180,80,255));
            for(int i=0;i<8;i++){
                float x = (i*97 + (t*18)%120) % (w+120) - 60;
                float y = dp(80) + (i*53)%((int)Math.max(1,h-dp(180)));
                c.drawCircle(x,y,dp(2+(i%3)),p);
            }
        }

        void drawTitle(Canvas c,float w,float y){
            p.setShader(null); p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD)); p.setTextSize(sp(25));
            c.drawText("九尾VTuber 推し活ライブ V3", w/2, y, p);
        }

        void drawStreamImage(Canvas c,float w,float top,float bottom,float t){
            if(sheet==null) return;
            Rect src = new Rect(0,0,sheet.getWidth(), (int)(sheet.getHeight()*0.56f));
            float bob=(float)Math.sin(t*2.1f)*dp(5);
            float breathe=1f+(float)Math.sin(t*1.7f)*0.012f;
            RectF base = new RectF(dp(8), top, w-dp(8), bottom);
            c.save();
            c.scale(breathe,breathe,base.centerX(),base.centerY());
            c.drawBitmap(sheet, src, new RectF(base.left,base.top+bob,base.right,base.bottom+bob), p);
            c.restore();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(Color.argb(160,230,205,255)); c.drawRoundRect(base,dp(8),dp(8),p); p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE); p.setTextSize(sp(24)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextAlign(Paint.Align.LEFT);
            c.drawText("● LIVE", dp(22), top+dp(38)+(float)Math.sin(t*5)*2, p);
        }

        void drawIdleEffects(Canvas c,float w,float top,float bottom,float t){
            float cx=w/2, cy=(top+bottom)/2;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(35,190,80,255));
            c.drawCircle(cx + (float)Math.sin(t*1.2f)*dp(9), cy + (float)Math.cos(t*1.7f)*dp(7), dp(105)+(float)Math.sin(t*2.5f)*dp(8), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3));
            p.setColor(Color.argb(110,210,150,255));
            for(int i=0;i<3;i++){
                float r=dp(65+i*25)+(float)Math.sin(t*2+i)*dp(4);
                c.drawCircle(cx, cy, r, p);
            }
            p.setStyle(Paint.Style.FILL);
        }

        void drawTextPanel(Canvas c,float w,float top,float btnTop,float t){
            float lineTop = top;
            p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD)); p.setTextSize(sp(22)); p.setColor(Color.WHITE);
            wrapText(c, line, w/2, lineTop+dp(30), w-dp(28), sp(29), 2);

            p.setTextAlign(Paint.Align.LEFT); p.setTextSize(sp(20)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setColor(Color.WHITE);
            c.drawText("合計: ¥"+String.format(Locale.JAPAN,"%,d",total), dp(12), lineTop+dp(94), p);
            c.drawText("好感度: "+affection, w*0.52f, lineTop+dp(94), p);
            p.setTextSize(sp(18)); c.drawText("COMBO: "+combo, dp(12), lineTop+dp(122), p);

            float gaugeX=dp(12), gaugeY=lineTop+dp(136), gaugeW=w-dp(24), gaugeH=dp(12);
            p.setColor(Color.argb(130,255,255,255)); c.drawRoundRect(new RectF(gaugeX,gaugeY,gaugeX+gaugeW,gaugeY+gaugeH),dp(8),dp(8),p);
            p.setColor(Color.rgb(190,90,255)); float fill=Math.min(1f,(affection%500)/500f); c.drawRoundRect(new RectF(gaugeX,gaugeY,gaugeX+gaugeW*fill,gaugeY+gaugeH),dp(8),dp(8),p);

            RectF chat = new RectF(dp(10), lineTop+dp(158), w-dp(10), btnTop-dp(10));
            p.setColor(Color.rgb(184,174,194)); c.drawRoundRect(chat,dp(10),dp(10),p);
            p.setColor(Color.rgb(45,25,65)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(sp(17)); c.drawText("コメント", chat.left+dp(12), chat.top+dp(24), p);
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(sp(15));
            int maxLines = Math.max(2, (int)((chat.height()-dp(34))/dp(21)));
            int startIdx=Math.max(0,comments.size()-maxLines);
            float y=chat.top+dp(47);
            for(int i=startIdx;i<comments.size();i++){ c.drawText(comments.get(i), chat.left+dp(14), y, p); y+=dp(21); }
        }

        void drawButtons(Canvas c,float w,float top,float bh,float t){
            float gap=dp(5); float left=dp(8); float bw=(w-left*2-gap*4)/5f;
            for(int i=0;i<5;i++){
                float x=left+i*(bw+gap); buttons[i]=new RectF(x, top, x+bw, top+bh);
                boolean hot = i==mood && (System.currentTimeMillis()-lastDonate)<700;
                p.setColor(hot ? Color.rgb(235,205,255) : Color.rgb(239,239,242));
                c.drawRoundRect(buttons[i],dp(8),dp(8),p);
                p.setColor(Color.rgb(32,25,38)); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(sp(16));
                c.drawText("¥"+String.format(Locale.JAPAN,"%,d",amounts[i]), x+bw/2, top+bh/2+dp(6), p);
            }
        }

        void drawParticles(Canvas c,float t){
            for(int i=particles.size()-1;i>=0;i--){
                Particle q=particles.get(i); float age=(System.currentTimeMillis()-q.birth)/1000f;
                if(age>1.6f){particles.remove(i); continue;}
                p.setColor(Color.argb((int)(255*(1-age/1.6f)), q.r,q.g,q.b)); p.setTextSize(q.size); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD);
                c.drawText(q.text, q.x + (float)Math.sin(age*8+q.seed)*dp(10), q.y-age*dp(105), p);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_DOWN) return true;
            for(int i=0;i<5;i++) if(buttons[i]!=null && buttons[i].contains(e.getX(),e.getY())){ donate(amounts[i], i); return true; }
            return true;
        }

        void donate(int amount, int idx){
            long now=System.currentTimeMillis();
            if(now-lastDonate>1800) combo=0;
            lastDonate=now; mood=idx;
            total+=amount; affection += Math.max(1, amount/100); combo++;
            String who=names[rnd.nextInt(names.length)]; comments.add("・"+who+"：¥"+String.format(Locale.JAPAN,"%,d",amount)+" こんこん！");
            if(comments.size()%5==0) comments.add(idleComments[rnd.nextInt(idleComments.length)]);
            if(amount>=5000) line = "紫月こんこん："+big[rnd.nextInt(big.length)];
            else if(amount>=1000) line = "紫月こんこん："+middle[rnd.nextInt(middle.length)];
            else line = "紫月こんこん："+small[rnd.nextInt(small.length)];
            int n= amount>=5000?55: amount>=1000?30:16;
            for(int k=0;k<n;k++) addParticle(amount>=5000 ? (rnd.nextBoolean()?"💜":"狐火") : (rnd.nextBoolean()?"♡":"✦"));
            performClick();
        }

        void addParticle(String text){
            Particle q=new Particle(); q.birth=System.currentTimeMillis();
            q.x=getWidth()/2f + rnd.nextInt(Math.max(1,getWidth()/2))-getWidth()/4f;
            q.y=getHeight()-dp(170)-rnd.nextInt(160);
            q.size=sp(16+rnd.nextInt(16)); q.text=text; q.r=190+rnd.nextInt(65); q.g=90+rnd.nextInt(90); q.b=255; q.seed=rnd.nextFloat()*10; particles.add(q);
        }

        @Override public boolean performClick(){ super.performClick(); return true; }

        void wrapText(Canvas c,String s,float cx,float y,float max,float lineH,int maxLines){
            p.setTextAlign(Paint.Align.CENTER); String[] chars=s.split(""); String line=""; int lines=0;
            for(String ch:chars){
                if(p.measureText(line+ch)>max && line.length()>0){ c.drawText(line,cx,y,p); y+=lineH; lines++; line=ch; if(lines>=maxLines-1) break; }
                else line+=ch;
            }
            c.drawText(line,cx,y,p);
        }
        int dp(float v){ return (int)(v*Resources.getSystem().getDisplayMetrics().density+0.5f); }
        float sp(float v){ return v*Resources.getSystem().getDisplayMetrics().scaledDensity; }
        static class Particle { float x,y,size,seed; long birth; int r,g,b; String text; }
    }
}
