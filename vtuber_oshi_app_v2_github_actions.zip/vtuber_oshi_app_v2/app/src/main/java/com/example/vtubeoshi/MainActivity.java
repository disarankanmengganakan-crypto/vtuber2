package com.example.vtubeoshi;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.graphics.*;
import android.content.Context;
import android.content.res.Resources;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(new OshiView(this)); }

    static class OshiView extends View {
        Bitmap sheet;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Random rnd = new Random();
        long start = System.currentTimeMillis();
        int total = 162700, affection = 327, combo = 0;
        String line = "紫月こんこん：今日も会いに来てくれてありがと！";
        ArrayList<Particle> particles = new ArrayList<>();
        ArrayList<String> comments = new ArrayList<>();
        int[] amounts = {100,500,1000,5000,10000};
        RectF[] buttons = new RectF[5];
        String[] names = {"きつね好き", "こんこん侍", "紫月推し", "九尾の民", "ないすぽ！"};
        String[] small = {"えへへ、応援ありがと！", "その気持ち、ちゃんと届いたよ！", "しっぽふりふりしちゃう！"};
        String[] big = {"わわっ！？大きな応援ありがとう！", "紫の狐火、全開でお礼するね！", "今日いちばん幸せかも……！"};

        OshiView(Context c){ super(c); setBackgroundColor(Color.rgb(31,10,48)); sheet = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("vtuber_sheet","drawable",c.getPackageName()));
            comments.add("・背景きれい"); comments.add("・紫月ちゃん動いてる！"); comments.add("・尻尾ふわふわかわいい"); comments.add("・投げ銭演出すごい！");
        }
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float w=getWidth(), h=getHeight(); float t=(System.currentTimeMillis()-start)/1000f; 
            p.setColor(Color.rgb(38,13,59)); c.drawRect(0,0,w,h,p);
            p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD)); p.setTextSize(sp(27)); c.drawText("九尾VTuber 推し活ライブ V2", w/2, dp(42), p);
            Rect src = new Rect(0,0,sheet.getWidth(), (int)(sheet.getHeight()*0.56)); RectF dst = new RectF(dp(8), dp(58), w-dp(8), dp(560)); c.drawBitmap(sheet, src, dst, p);
            float bob=(float)Math.sin(t*2.2f)*12; p.setColor(Color.argb(45,185,95,255)); c.drawCircle(w/2, dp(300)+bob, dp(140)+(float)Math.sin(t*3)*8, p);
            p.setColor(Color.WHITE); p.setTextSize(sp(28)); p.setTextAlign(Paint.Align.LEFT); c.drawText("● LIVE", dp(22), dp(90)+(float)Math.sin(t*4)*2, p);
            drawParticles(c, t);
            p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD)); p.setTextSize(sp(24)); p.setColor(Color.WHITE); wrapText(c, line, w/2, dp(610), w-dp(18), sp(30));
            p.setTextAlign(Paint.Align.LEFT); p.setTextSize(sp(22)); c.drawText("合計: ¥"+String.format(Locale.JAPAN,"%,d",total), dp(10), dp(685), p); c.drawText("好感度: "+affection, w/2, dp(685), p); c.drawText("COMBO: "+combo, dp(10), dp(715), p);
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(sp(18)); p.setColor(Color.rgb(40,25,58)); RectF chat = new RectF(dp(10), dp(728), w-dp(10), dp(815)); p.setColor(Color.rgb(172,162,181)); c.drawRoundRect(chat,dp(8),dp(8),p); p.setColor(Color.rgb(45,25,65)); c.drawText("コメント", dp(20), dp(755), p); int y=780; for(int i=Math.max(0,comments.size()-4);i<comments.size();i++){ c.drawText(comments.get(i), dp(25), dp(y), p); y+=22; }
            float bw=(w-dp(28))/5f; for(int i=0;i<5;i++){ float x=dp(8)+i*(bw+dp(3)); buttons[i]=new RectF(x, dp(832), x+bw, dp(885)); p.setColor(Color.rgb(238,238,240)); c.drawRoundRect(buttons[i],dp(6),dp(6),p); p.setColor(Color.rgb(30,25,35)); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(sp(18)); c.drawText("¥"+String.format(Locale.JAPAN,"%,d",amounts[i]), x+bw/2, dp(865), p); }
            invalidate();
        }
        void drawParticles(Canvas c,float t){ for(int i=particles.size()-1;i>=0;i--){ Particle q=particles.get(i); float age=(System.currentTimeMillis()-q.birth)/1000f; if(age>1.5f){particles.remove(i); continue;} p.setColor(Color.argb((int)(255*(1-age/1.5f)), q.r,q.g,q.b)); p.setTextSize(q.size); p.setTextAlign(Paint.Align.CENTER); c.drawText(q.text, q.x, q.y-age*120, p); q.x += Math.sin(age*6+q.seed)*1.5f; } }
        @Override public boolean onTouchEvent(MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_DOWN) return true; for(int i=0;i<5;i++) if(buttons[i]!=null && buttons[i].contains(e.getX(),e.getY())){ donate(amounts[i]); return true; } return true; }
        void donate(int amount){ total+=amount; affection += Math.max(1, amount/100); combo++; String who=names[rnd.nextInt(names.length)]; comments.add("・"+who+"：¥"+amount+" こんこん！"); line = amount>=5000 ? "紫月こんこん："+big[rnd.nextInt(big.length)] : "紫月こんこん："+small[rnd.nextInt(small.length)]; int n= amount>=5000?44:18; for(int k=0;k<n;k++){ Particle q=new Particle(); q.birth=System.currentTimeMillis(); q.x=getWidth()/2 + rnd.nextInt(Math.max(1,getWidth()/2))-getWidth()/4; q.y=dp(610)+rnd.nextInt(180); q.size=sp(18+rnd.nextInt(18)); q.text = rnd.nextBoolean()?"💜":"狐火"; q.r=190+rnd.nextInt(65); q.g=90+rnd.nextInt(80); q.b=255; q.seed=rnd.nextFloat()*10; particles.add(q); } }
        void wrapText(Canvas c,String s,float cx,float y,float max,float lineH){ p.setTextAlign(Paint.Align.CENTER); String[] chars=s.split(""); String line=""; for(String ch:chars){ if(p.measureText(line+ch)>max){ c.drawText(line,cx,y,p); y+=lineH; line=ch; } else line+=ch; } c.drawText(line,cx,y,p); }
        int dp(float v){ return (int)(v*Resources.getSystem().getDisplayMetrics().density+0.5f); } float sp(float v){ return v*Resources.getSystem().getDisplayMetrics().scaledDensity; }
        static class Particle { float x,y,size,seed; long birth; int r,g,b; String text; }
    }
}
