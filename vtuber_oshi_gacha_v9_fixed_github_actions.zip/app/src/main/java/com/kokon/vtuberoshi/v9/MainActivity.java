package com.kokon.vtuberoshi.v9;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    int totalDonated = 0, affection = 0, stage = 1, expr = 0, wallet = 0, selectedBet = 100;
    ImageView charView, bgView;
    TextView line, totalView, affView, walletView, unlockView, commentView, titleView, puzzleView, slotView;
    GridLayout moneyGrid;
    LinearLayout betRow;
    boolean inStream = false;
    Random rnd = new Random();
    int[] amounts = {240, 1000, 5000, 10000, 50000};
    boolean[] unlocked = {true, true, false, false, false};
    String[] comments = {"Miiちゃん今日もかわいい！", "配信部屋めっちゃ似合ってる", "応援してるよ！"};
    String[] slotSymbols = {"🐾", "💜", "🎤", "⭐", "7"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        showTitle();
    }

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    String yen(int n) { return "￥" + NumberFormat.getNumberInstance().format(n); }

    TextView tv(String s, int sp, int c, int style) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(c); v.setTypeface(Typeface.DEFAULT, style);
        v.setPadding(dp(6), dp(4), dp(6), dp(4)); return v;
    }

    GradientDrawable round(int color, int strokeColor, int strokeWidth, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        if (strokeWidth > 0) g.setStroke(dp(strokeWidth), strokeColor);
        return g;
    }

    Button btn(String text, int sp) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(sp); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false);
        b.setSingleLine(false); b.setPadding(dp(4), 0, dp(4), 0);
        b.setTextColor(0xff26142f);
        b.setBackground(round(0xfff7f0fb, 0xffff5b79, 2, 16));
        return b;
    }

    public void showTitle() {
        inStream = false;
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(12, 0, 24));
        ImageView titleBg = new ImageView(this);
        titleBg.setImageResource(getResources().getIdentifier("title_bg", "drawable", getPackageName()));
        titleBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(titleBg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x77000000, 0x11000000, 0xaa080012}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("title_logo", "drawable", getPackageName()));
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(dp(520), dp(170));
        logoLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL; logoLp.topMargin = dp(8);
        root.addView(logo, logoLp); pulseLoop(logo);
        TextView version = tv("V9：稼いで、賭けて、推しに貢ぐ", 17, Color.WHITE, Typeface.BOLD);
        version.setGravity(Gravity.CENTER); version.setShadowLayer(dp(8),0,0,Color.BLACK);
        version.setBackground(round(0x77000000, 0x66ff77bb, 1, 20));
        FrameLayout.LayoutParams vl = new FrameLayout.LayoutParams(dp(390), dp(46));
        vl.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL; vl.bottomMargin = dp(16);
        root.addView(version, vl);
        String[] labels = {"Mii 配信へ", "準備中", "準備中", "準備中"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView hot = tv(labels[i], 14, Color.WHITE, Typeface.BOLD);
            hot.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL); hot.setShadowLayer(dp(5), 0, 0, Color.BLACK);
            hot.setBackgroundColor(Color.TRANSPARENT);
            FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels / 4, -1);
            hp.leftMargin = hp.width * i; root.addView(hot, hp);
            hot.setOnClickListener(v -> { if (idx == 0) { buildStream(); updateAll(); startFloat(); } else Toast.makeText(this, "キャラ"+(idx+1)+"は準備中です", Toast.LENGTH_SHORT).show(); });
        }
        setContentView(root);
    }

    public void buildStream() {
        inStream = true;
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(Color.rgb(20, 0, 28));
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.HORIZONTAL); main.setPadding(dp(8), dp(6), dp(8), dp(6));
        root.addView(main, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout live = new FrameLayout(this); main.addView(live, new LinearLayout.LayoutParams(0, -1, 7));
        bgView = new ImageView(this); bgView.setScaleType(ImageView.ScaleType.CENTER_CROP); bgView.setImageResource(getResources().getIdentifier("bg_stream", "drawable", getPackageName()));
        live.addView(bgView, new FrameLayout.LayoutParams(-1, -1));
        charView = new ImageView(this); charView.setScaleType(ImageView.ScaleType.FIT_CENTER); live.addView(charView, new FrameLayout.LayoutParams(-1, -1));
        live.setOnClickListener(v -> { expr = (expr + 1) % 2; reactTap(); });
        TextView liveTxt = tv("● LIVE", 25, Color.WHITE, Typeface.BOLD); liveTxt.setShadowLayer(dp(8),0,0,Color.BLACK);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2); lp.leftMargin = dp(16); lp.topMargin = dp(10); live.addView(liveTxt, lp);
        TextView back = tv("← TITLE", 13, Color.WHITE, Typeface.BOLD); back.setShadowLayer(dp(6),0,0,Color.BLACK); back.setBackground(round(0x66000000, 0x66ffffff, 1, 14));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2); bp.gravity = Gravity.TOP | Gravity.RIGHT; bp.topMargin = dp(10); bp.rightMargin = dp(10); live.addView(back, bp); back.setOnClickListener(v -> showTitle());
        TextView tapHint = tv("TAPで表情変更", 13, 0xffffe6ef, Typeface.BOLD); tapHint.setShadowLayer(dp(6),0,0,Color.BLACK);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2); hp.leftMargin = dp(16); hp.gravity = Gravity.BOTTOM | Gravity.LEFT; hp.bottomMargin = dp(12); live.addView(tapHint, hp);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); main.addView(scroll, new LinearLayout.LayoutParams(0, -1, 3));
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(12), dp(4), dp(8), dp(12)); scroll.addView(panel, new ScrollView.LayoutParams(-1, -2));
        titleView = tv("Mii 推しライブ V9", 20, Color.WHITE, Typeface.BOLD); titleView.setGravity(Gravity.CENTER); panel.addView(titleView, new LinearLayout.LayoutParams(-1, -2));
        line = tv("Mii：今日も会いに来てくれてありがとう！", 15, Color.WHITE, Typeface.BOLD); line.setGravity(Gravity.CENTER); line.setBackground(round(0x33100020, 0x55ff5b79, 1, 18)); panel.addView(line, new LinearLayout.LayoutParams(-1, dp(76)));
        walletView = tv("", 16, 0xfffff1a6, Typeface.BOLD); totalView = tv("", 15, Color.WHITE, Typeface.BOLD); affView = tv("", 15, Color.WHITE, Typeface.BOLD); unlockView = tv("", 11, 0xffffd6e2, Typeface.BOLD);
        panel.addView(walletView); panel.addView(totalView); panel.addView(affView); panel.addView(unlockView);
        commentView = tv("", 12, 0xff26142f, Typeface.NORMAL); commentView.setBackground(round(0xeef2e8f5, 0, 0, 16)); panel.addView(commentView, new LinearLayout.LayoutParams(-1, dp(82)));

        TextView earnTitle = tv("無料パズルで稼ぐ", 14, 0xffffd6e2, Typeface.BOLD); earnTitle.setGravity(Gravity.CENTER); panel.addView(earnTitle);
        puzzleView = tv("3つの肉球から当たりを選んでね", 12, Color.WHITE, Typeface.BOLD); puzzleView.setGravity(Gravity.CENTER); panel.addView(puzzleView, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout puzzleRow = new LinearLayout(this); puzzleRow.setOrientation(LinearLayout.HORIZONTAL); panel.addView(puzzleRow, new LinearLayout.LayoutParams(-1, dp(46)));
        for (int i=0;i<3;i++){ final int idx=i; Button p=btn("🐾",18); p.setOnClickListener(v -> playPuzzle(idx)); puzzleRow.addView(p, new LinearLayout.LayoutParams(0, -1, 1)); }

        TextView slotTitle = tv("スロットで増やす", 14, 0xffffd6e2, Typeface.BOLD); slotTitle.setGravity(Gravity.CENTER); panel.addView(slotTitle);
        slotView = tv("[ ? ] [ ? ] [ ? ]", 20, Color.WHITE, Typeface.BOLD); slotView.setGravity(Gravity.CENTER); slotView.setBackground(round(0x33100020, 0x55b44cff, 1, 14)); panel.addView(slotView, new LinearLayout.LayoutParams(-1, dp(48)));
        betRow = new LinearLayout(this); betRow.setOrientation(LinearLayout.HORIZONTAL); panel.addView(betRow, new LinearLayout.LayoutParams(-1, dp(38)));
        int[] bets = {100,500,1000};
        for(int bet:bets){ Button b=btn(yen(bet),10); b.setOnClickListener(v->{ selectedBet=bet; updateAll(); }); betRow.addView(b, new LinearLayout.LayoutParams(0,-1,1)); }
        Button spin=btn("SPIN / BET " + yen(selectedBet), 13); spin.setOnClickListener(v -> playSlot()); panel.addView(spin, new LinearLayout.LayoutParams(-1, dp(44)));

        TextView donateTitle = tv("投げ銭", 14, 0xffffd6e2, Typeface.BOLD); donateTitle.setGravity(Gravity.CENTER); panel.addView(donateTitle);
        moneyGrid = new GridLayout(this); moneyGrid.setColumnCount(2); moneyGrid.setPadding(0, dp(2), 0, dp(2)); panel.addView(moneyGrid, new LinearLayout.LayoutParams(-1, -2));
        Button reset = btn("RESET", 11); reset.setOnClickListener(v -> { totalDonated=0; affection=0; stage=1; expr=0; wallet=0; selectedBet=100; Arrays.fill(unlocked,false); unlocked[0]=unlocked[1]=true; updateAll(); }); panel.addView(reset, new LinearLayout.LayoutParams(-1, dp(38)));
        setContentView(root);
    }

    void playPuzzle(int choice) {
        int hit = rnd.nextInt(3); int gain = (choice == hit) ? 120 + rnd.nextInt(181) : 20 + rnd.nextInt(51);
        wallet += gain; puzzleView.setText(choice == hit ? "大当たり！ +" + yen(gain) : "惜しい！参加賞 +" + yen(gain));
        addComment("あなた：パズルで" + yen(gain) + "稼いだ！"); updateAll();
    }

    void playSlot() {
        if (wallet < selectedBet) { Toast.makeText(this, "所持金が足りないよ。まずはパズルで稼ごう！", Toast.LENGTH_SHORT).show(); return; }
        wallet -= selectedBet;
        String a=slotSymbols[rnd.nextInt(slotSymbols.length)], b=slotSymbols[rnd.nextInt(slotSymbols.length)], c=slotSymbols[rnd.nextInt(slotSymbols.length)];
        int reward = 0; String msg = "ハズレ…";
        if (a.equals(b) && b.equals(c)) { reward = selectedBet * (a.equals("7") ? 10 : 5); msg = "JACKPOT！"; }
        else if (a.equals(b) || b.equals(c) || a.equals(c)) { reward = selectedBet * 2; msg = "2つ揃い！"; }
        wallet += reward; slotView.setText("[ " + a + " ] [ " + b + " ] [ " + c + " ]");
        addComment("スロット：" + msg + " " + (reward>0?"+"+yen(reward):"-"+yen(selectedBet)));
        if (reward > 0) { line.setText("Mii：すごい！その運、私にも見せて？"); pulse(charView); }
        updateAll();
    }

    void makeButtons() {
        moneyGrid.removeAllViews();
        for (int i = 0; i < amounts.length; i++) {
            final int a = amounts[i]; boolean can = unlocked[i] && wallet >= a;
            Button bt = btn((unlocked[i] ? yen(a) : "🔒" + yen(a)) + (unlocked[i] && wallet<a ? "\n不足" : ""), 10);
            bt.setEnabled(can); bt.setAlpha(can ? 1f : 0.58f);
            bt.setOnClickListener(v -> donate(a));
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams(); gp.width = 0; gp.height = dp(48); gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); gp.setMargins(dp(3), dp(3), dp(3), dp(3));
            moneyGrid.addView(bt, gp);
        }
    }

    void donate(int a) {
        if (wallet < a) { Toast.makeText(this, "所持金不足！稼いでから貢ごう", Toast.LENGTH_SHORT).show(); return; }
        wallet -= a; totalDonated += a; affection += Math.max(1, a / 120);
        line.setText("Mii：" + yen(a) + "ありがとう！大事にするね！"); addComment("あなた：" + yen(a) + " 投げ銭！"); checkUnlock(); pulse(charView); updateAll();
    }

    void checkUnlock() {
        int old = stage;
        if (totalDonated >= 10000) { unlocked[3] = true; stage = 3; }
        else if (totalDonated >= 5000) { unlocked[2] = true; stage = 2; }
        if (totalDonated >= 50000) unlocked[4] = true;
        if (stage > old) unlockEffect();
    }

    void unlockEffect() {
        line.setText(stage == 2 ? "Mii：新しい姿、見せちゃうね…！" : "Mii：ここまで応援してくれたんだね…♡");
        final TextView flash = tv("STAGE UP!", 40, 0xffffd1e6, Typeface.BOLD); flash.setGravity(Gravity.CENTER); flash.setShadowLayer(dp(12),0,0,0xffff2d80);
        addContentView(flash, new ViewGroup.LayoutParams(-1, -1));
        AlphaAnimation aa = new AlphaAnimation(1, 0); aa.setDuration(1500);
        aa.setAnimationListener(new Animation.AnimationListener(){ public void onAnimationStart(Animation a){} public void onAnimationRepeat(Animation a){} public void onAnimationEnd(Animation a){ ((ViewGroup)flash.getParent()).removeView(flash); }});
        flash.startAnimation(aa);
    }

    void reactTap() {
        if (stage == 1) line.setText(expr == 1 ? "Mii：ふふ、見つめすぎだよ…？" : "Mii：今日も会いに来てくれてありがとう！");
        else line.setText(stage == 2 ? "Mii：この姿、どうかな…？" : "Mii：もっと近くで見ててね");
        updateImage(); pulse(charView);
    }

    void updateAll() {
        checkUnlock(); updateImage(); makeButtons();
        walletView.setText("所持金：" + yen(wallet));
        totalView.setText("累計投げ銭：" + yen(totalDonated));
        affView.setText("好感度：" + affection);
        unlockView.setText("解放：￥240 / ￥1,000" + (unlocked[2]?" / ￥5,000":" / 🔒￥5,000") + (unlocked[3]?" / ￥10,000":" / 🔒￥10,000") + (unlocked[4]?" / ￥50,000":" / 🔒￥50,000"));
        commentView.setText("コメント\n・" + String.join("\n・", comments));
        if (betRow != null) {
            for (int i=0;i<betRow.getChildCount();i++) {
                Button b=(Button)betRow.getChildAt(i); int bet = (i==0?100:(i==1?500:1000));
                b.setText((selectedBet==bet?"▶ ":"") + yen(bet));
            }
        }
    }

    void updateImage() {
        if (charView == null) return;
        String name = "stage1_idle";
        if (stage == 1 && expr == 1) name = "stage1_blush"; else if (stage == 2) name = "stage2_idle"; else if (stage >= 3) name = "stage3_idle";
        charView.setImageResource(getResources().getIdentifier(name, "drawable", getPackageName()));
    }

    void addComment(String s) {
        ArrayList<String> list = new ArrayList<>(); list.add(s); for (String c : comments) list.add(c); while (list.size() > 4) list.remove(list.size() - 1); comments = list.toArray(new String[0]);
    }
    void pulse(View v) { ScaleAnimation s = new ScaleAnimation(1f,1.035f,1f,1.035f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f); s.setDuration(170); s.setRepeatCount(1); s.setRepeatMode(Animation.REVERSE); v.startAnimation(s); }
    void pulseLoop(View v) { ScaleAnimation s = new ScaleAnimation(1f,1.035f,1f,1.035f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f); s.setDuration(1150); s.setRepeatCount(Animation.INFINITE); s.setRepeatMode(Animation.REVERSE); v.startAnimation(s); }
    void startFloat() { if (charView==null) return; TranslateAnimation t = new TranslateAnimation(0,0,-5,5); t.setDuration(1800); t.setRepeatCount(Animation.INFINITE); t.setRepeatMode(Animation.REVERSE); charView.startAnimation(t); }
    @Override public void onBackPressed() { if (inStream) showTitle(); else super.onBackPressed(); }
}
