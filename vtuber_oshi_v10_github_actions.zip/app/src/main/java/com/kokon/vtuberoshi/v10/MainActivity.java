package com.kokon.vtuberoshi.v10;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    int totalDonated = 0, affection = 0, stage = 1, expr = 0, wallet = 1000, selectedBet = 100;
    ImageView charView, bgView; TextView speechView, totalView, affView, walletView, unlockView, commentView, titleView;
    TextView scratchResultView, miniWalletView, slotMsgView; LinearLayout reelRow, betRow; GridLayout moneyGrid;
    boolean inStream = false, inMini = false; Random rnd = new Random();
    int[] amounts = {240, 1000, 5000, 10000, 50000};
    boolean[] unlocked = {true, true, false, false, false};
    String[] comments = {"Miiちゃん今日もかわいい！", "配信部屋めっちゃ似合ってる", "応援してるよ！"};
    String[] symbolNames = {"slot_char1", "slot_char2", "slot_char3", "slot_char4", "slot_cat", "slot_heart", "slot_fire", "slot_syringe"};
    String[] symbolLabels = {"Mii", "Choco", "Mel", "Okayu", "Cat", "Heart", "Fire", "Syringe"};

    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); showTitle(); }
    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    String yen(int n) { return "￥" + NumberFormat.getNumberInstance().format(n); }
    int res(String n) { return getResources().getIdentifier(n, "drawable", getPackageName()); }

    TextView tv(String s, int sp, int c, int style) { TextView v = new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(c); v.setTypeface(Typeface.DEFAULT, style); v.setPadding(dp(6), dp(4), dp(6), dp(4)); return v; }
    GradientDrawable round(int color, int strokeColor, int strokeWidth, int radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); if (strokeWidth > 0) g.setStroke(dp(strokeWidth), strokeColor); return g; }
    Button btn(String text, int sp) { Button b = new Button(this); b.setText(text); b.setTextSize(sp); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false); b.setSingleLine(false); b.setPadding(dp(4), 0, dp(4), 0); b.setTextColor(0xff26142f); b.setBackground(round(0xfff7f0fb, 0xffff5b79, 2, 16)); return b; }

    public void showTitle() {
        inStream = false; inMini = false;
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(0xff100018);
        ImageView titleBg = new ImageView(this); titleBg.setImageResource(res("title_bg")); titleBg.setScaleType(ImageView.ScaleType.CENTER_CROP); root.addView(titleBg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this); shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x77000000,0x11000000,0xcc080012})); root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        ImageView logo = new ImageView(this); logo.setImageResource(res("title_logo")); logo.setScaleType(ImageView.ScaleType.FIT_CENTER); FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(dp(540), dp(160)); logoLp.gravity = Gravity.TOP|Gravity.CENTER_HORIZONTAL; logoLp.topMargin = dp(4); root.addView(logo, logoLp); pulseLoop(logo);
        LinearLayout menu = new LinearLayout(this); menu.setOrientation(LinearLayout.HORIZONTAL); menu.setGravity(Gravity.CENTER); menu.setPadding(dp(12),0,dp(12),0); FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(620), dp(72)); mp.gravity = Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL; mp.bottomMargin = dp(18); root.addView(menu, mp);
        Button stream = btn("▶ 配信を見る", 17); Button mini = btn("🎮 ミニゲームで稼ぐ", 17); menu.addView(stream, new LinearLayout.LayoutParams(0,-1,1)); LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(dp(16), -1); Space sp = new Space(this); menu.addView(sp, gap); menu.addView(mini, new LinearLayout.LayoutParams(0,-1,1));
        stream.setOnClickListener(v -> { buildStream(); updateStreamAll(); startFloat(); }); mini.setOnClickListener(v -> buildMiniGame());
        String[] labels = {"Mii 配信", "準備中", "準備中", "準備中"};
        for (int i=0;i<4;i++){ final int idx=i; TextView hot=tv(labels[i],13,Color.WHITE,Typeface.BOLD); hot.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL); hot.setShadowLayer(dp(5),0,0,Color.BLACK); hot.setPadding(0,dp(170),0,0); FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels/4, -1); hp.leftMargin=hp.width*i; root.addView(hot,hp); hot.setOnClickListener(v->{ if(idx==0){buildStream(); updateStreamAll(); startFloat();} else Toast.makeText(this,"キャラ"+(idx+1)+"は準備中です",Toast.LENGTH_SHORT).show(); }); }
        setContentView(root);
    }

    public void buildStream() {
        inStream = true; inMini = false;
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(0xff14001c);
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.HORIZONTAL); main.setPadding(dp(8),dp(6),dp(8),dp(6)); root.addView(main, new FrameLayout.LayoutParams(-1,-1));
        FrameLayout live = new FrameLayout(this); main.addView(live, new LinearLayout.LayoutParams(0,-1,7));
        bgView = new ImageView(this); bgView.setImageResource(res("bg_stream")); bgView.setScaleType(ImageView.ScaleType.CENTER_CROP); live.addView(bgView, new FrameLayout.LayoutParams(-1,-1));
        charView = new ImageView(this); charView.setScaleType(ImageView.ScaleType.FIT_CENTER); live.addView(charView, new FrameLayout.LayoutParams(-1,-1));
        live.setOnClickListener(v->{ expr=(expr+1)%2; reactTap(); });
        TextView liveTxt = tv("● LIVE",25,Color.WHITE,Typeface.BOLD); liveTxt.setShadowLayer(dp(8),0,0,Color.BLACK); FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-2,-2); lp.leftMargin=dp(16); lp.topMargin=dp(10); live.addView(liveTxt,lp);
        TextView back = tv("← TITLE",13,Color.WHITE,Typeface.BOLD); back.setShadowLayer(dp(6),0,0,Color.BLACK); back.setBackground(round(0x66000000,0x66ffffff,1,14)); FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-2,-2); bp.gravity=Gravity.TOP|Gravity.RIGHT; bp.topMargin=dp(10); bp.rightMargin=dp(10); live.addView(back,bp); back.setOnClickListener(v->showTitle());
        speechView = tv("Mii：今日も会いに来てくれてありがとう！",16,Color.WHITE,Typeface.BOLD); speechView.setGravity(Gravity.CENTER); speechView.setBackground(round(0xcc2a063a,0xffff75a4,2,20)); speechView.setShadowLayer(dp(4),0,0,0xff000000); FrameLayout.LayoutParams slp=new FrameLayout.LayoutParams(dp(360), dp(78)); slp.gravity=Gravity.RIGHT|Gravity.TOP; slp.topMargin=dp(78); slp.rightMargin=dp(22); live.addView(speechView,slp);
        TextView tapHint = tv("TAPで表情変更",13,0xffffe6ef,Typeface.BOLD); tapHint.setShadowLayer(dp(6),0,0,Color.BLACK); FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-2,-2); hp.gravity=Gravity.BOTTOM|Gravity.LEFT; hp.leftMargin=dp(16); hp.bottomMargin=dp(12); live.addView(tapHint,hp);
        ScrollView scroll = new ScrollView(this); main.addView(scroll, new LinearLayout.LayoutParams(0,-1,3));
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(12),dp(4),dp(8),dp(12)); scroll.addView(panel, new ScrollView.LayoutParams(-1,-2));
        titleView=tv("Mii 推しライブ V10",20,Color.WHITE,Typeface.BOLD); titleView.setGravity(Gravity.CENTER); panel.addView(titleView,new LinearLayout.LayoutParams(-1,-2));
        walletView=tv("",16,0xfffff1a6,Typeface.BOLD); totalView=tv("",15,Color.WHITE,Typeface.BOLD); affView=tv("",15,Color.WHITE,Typeface.BOLD); unlockView=tv("",11,0xffffd6e2,Typeface.BOLD); panel.addView(walletView); panel.addView(totalView); panel.addView(affView); panel.addView(unlockView);
        commentView=tv("",12,0xff26142f,Typeface.NORMAL); commentView.setBackground(round(0xeef2e8f5,0,0,16)); panel.addView(commentView,new LinearLayout.LayoutParams(-1, dp(92)));
        TextView donateTitle=tv("投げ銭",14,0xffffd6e2,Typeface.BOLD); donateTitle.setGravity(Gravity.CENTER); panel.addView(donateTitle);
        moneyGrid=new GridLayout(this); moneyGrid.setColumnCount(2); moneyGrid.setPadding(0,dp(2),0,dp(2)); panel.addView(moneyGrid,new LinearLayout.LayoutParams(-1,-2));
        Button toMini=btn("ミニゲームで稼ぐ",12); toMini.setOnClickListener(v->buildMiniGame()); panel.addView(toMini,new LinearLayout.LayoutParams(-1,dp(42)));
        Button reset=btn("RESET",11); reset.setOnClickListener(v->{ totalDonated=0; affection=0; stage=1; expr=0; wallet=1000; selectedBet=100; Arrays.fill(unlocked,false); unlocked[0]=unlocked[1]=true; updateStreamAll(); }); panel.addView(reset,new LinearLayout.LayoutParams(-1,dp(38)));
        setContentView(root);
    }

    public void buildMiniGame() {
        inStream=false; inMini=true;
        FrameLayout root = new FrameLayout(this); root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xff260034,0xff090010,0xff3b0a4f}));
        LinearLayout all = new LinearLayout(this); all.setOrientation(LinearLayout.HORIZONTAL); all.setPadding(dp(14),dp(12),dp(14),dp(12)); root.addView(all,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL); left.setGravity(Gravity.CENTER); left.setPadding(dp(8),0,dp(12),0); all.addView(left,new LinearLayout.LayoutParams(0,-1,4));
        LinearLayout right = new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL); right.setPadding(dp(12),0,dp(8),0); all.addView(right,new LinearLayout.LayoutParams(0,-1,6));
        TextView title=tv("ミニゲームで稼ぐ V10",26,Color.WHITE,Typeface.BOLD); title.setGravity(Gravity.CENTER); left.addView(title,new LinearLayout.LayoutParams(-1,-2));
        miniWalletView=tv("",22,0xfffff1a6,Typeface.BOLD); miniWalletView.setGravity(Gravity.CENTER); left.addView(miniWalletView,new LinearLayout.LayoutParams(-1,-2));
        TextView desc=tv("スクラッチで無料収入 → スロットで勝負 → 配信で投げ銭！",14,0xffffd6e2,Typeface.BOLD); desc.setGravity(Gravity.CENTER); left.addView(desc,new LinearLayout.LayoutParams(-1,-2));
        Button back=btn("← TITLE",14); back.setOnClickListener(v->showTitle()); left.addView(back,new LinearLayout.LayoutParams(-1,dp(44)));
        Button stream=btn("配信へ戻る",14); stream.setOnClickListener(v->{buildStream(); updateStreamAll(); startFloat();}); left.addView(stream,new LinearLayout.LayoutParams(-1,dp(44)));
        TextView scTitle=tv("🧩 1マス スクラッチ",20,Color.WHITE,Typeface.BOLD); scTitle.setGravity(Gravity.CENTER); right.addView(scTitle,new LinearLayout.LayoutParams(-1,-2));
        scratchResultView=tv("タップして削る！",18,Color.WHITE,Typeface.BOLD); scratchResultView.setGravity(Gravity.CENTER); scratchResultView.setBackground(round(0xff4c2858,0xffff75a4,2,24)); right.addView(scratchResultView,new LinearLayout.LayoutParams(-1,dp(70)));
        Button scratch=btn("SCRATCH! 無料",18); scratch.setOnClickListener(v->playScratch()); right.addView(scratch,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView slTitle=tv("🎰 推しスロット",20,Color.WHITE,Typeface.BOLD); slTitle.setGravity(Gravity.CENTER); right.addView(slTitle,new LinearLayout.LayoutParams(-1,-2));
        reelRow=new LinearLayout(this); reelRow.setGravity(Gravity.CENTER); reelRow.setOrientation(LinearLayout.HORIZONTAL); right.addView(reelRow,new LinearLayout.LayoutParams(-1,dp(118))); for(int i=0;i<3;i++){ ImageView iv=new ImageView(this); iv.setImageResource(res("slot_cat")); iv.setScaleType(ImageView.ScaleType.FIT_CENTER); iv.setBackground(round(0x99ffffff,0xffff75a4,2,20)); LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(0,-1,1); rlp.setMargins(dp(5),dp(6),dp(5),dp(6)); reelRow.addView(iv,rlp); }
        slotMsgView=tv("BETを選んでSPIN！",15,Color.WHITE,Typeface.BOLD); slotMsgView.setGravity(Gravity.CENTER); right.addView(slotMsgView,new LinearLayout.LayoutParams(-1,-2));
        betRow=new LinearLayout(this); betRow.setOrientation(LinearLayout.HORIZONTAL); right.addView(betRow,new LinearLayout.LayoutParams(-1,dp(42))); int[] bets={100,500,1000}; for(int bet:bets){ Button b=btn(yen(bet),11); b.setOnClickListener(v->{selectedBet=bet; updateMiniAll();}); betRow.addView(b,new LinearLayout.LayoutParams(0,-1,1)); }
        Button spin=btn("SPIN",18); spin.setOnClickListener(v->playSlot()); right.addView(spin,new LinearLayout.LayoutParams(-1,dp(54)));
        setContentView(root); updateMiniAll();
    }

    void playScratch(){ int[] rewards={50,80,100,150,200,300,500,0}; int gain=rewards[rnd.nextInt(rewards.length)]; wallet+=gain; scratchResultView.setText(gain>0?"✨ 当たり！ +"+yen(gain):"ハズレ…でも無料だからOK！"); if(gain>0) pulse(scratchResultView); updateMiniAll(); }
    void playSlot(){ if(wallet<selectedBet){Toast.makeText(this,"所持金が足りないよ。スクラッチで稼ごう！",Toast.LENGTH_SHORT).show(); return;} wallet-=selectedBet; int[] ids=new int[3]; for(int i=0;i<3;i++){ ids[i]=rnd.nextInt(symbolNames.length); ImageView iv=(ImageView)reelRow.getChildAt(i); iv.setImageResource(res(symbolNames[ids[i]])); pulse(iv); } int reward=0; String msg="ハズレ… -"+yen(selectedBet); if(ids[0]==ids[1]&&ids[1]==ids[2]){ int mul = ids[0] < 4 ? 10 : (ids[0]==7?7:5); reward=selectedBet*mul; msg="JACKPOT！ "+symbolLabels[ids[0]]+" ×"+mul+" +"+yen(reward); } else if(ids[0]==ids[1]||ids[1]==ids[2]||ids[0]==ids[2]){ reward=selectedBet*2; msg="2つ揃い！ +"+yen(reward); } wallet+=reward; slotMsgView.setText(msg); if(reward>0) pulse(slotMsgView); updateMiniAll(); }
    void updateMiniAll(){ if(miniWalletView!=null) miniWalletView.setText("所持金："+yen(wallet)); if(betRow!=null){ for(int i=0;i<betRow.getChildCount();i++){ Button b=(Button)betRow.getChildAt(i); int bet=(i==0?100:(i==1?500:1000)); b.setText((selectedBet==bet?"▶ ":"")+yen(bet)); } } }

    void makeButtons(){ if(moneyGrid==null)return; moneyGrid.removeAllViews(); for(int i=0;i<amounts.length;i++){ final int a=amounts[i]; boolean can=unlocked[i]&&wallet>=a; Button bt=btn((unlocked[i]?yen(a):"🔒"+yen(a))+(unlocked[i]&&wallet<a?"\n不足":""),10); bt.setEnabled(can); bt.setAlpha(can?1f:0.55f); bt.setOnClickListener(v->donate(a)); GridLayout.LayoutParams gp=new GridLayout.LayoutParams(); gp.width=0; gp.height=dp(46); gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); gp.setMargins(dp(3),dp(3),dp(3),dp(3)); moneyGrid.addView(bt,gp); } }
    void donate(int a){ if(wallet<a){Toast.makeText(this,"所持金不足！ミニゲームで稼ごう",Toast.LENGTH_SHORT).show(); return;} wallet-=a; totalDonated+=a; affection+=Math.max(1,a/120); showSpeech("Mii："+yen(a)+"ありがとう！大事にするね！"); addComment("あなた："+yen(a)+" 投げ銭！"); checkUnlock(); pulse(charView); updateStreamAll(); }
    void checkUnlock(){ int old=stage; if(totalDonated>=10000){unlocked[3]=true; stage=3;} else if(totalDonated>=5000){unlocked[2]=true; stage=2;} if(totalDonated>=50000)unlocked[4]=true; if(stage>old)unlockEffect(); }
    void unlockEffect(){ showSpeech(stage==2?"Mii：新しい姿、見せちゃうね…！":"Mii：ここまで応援してくれたんだね…♡"); final TextView flash=tv("STAGE UP!",40,0xffffd1e6,Typeface.BOLD); flash.setGravity(Gravity.CENTER); flash.setShadowLayer(dp(12),0,0,0xffff2d80); addContentView(flash,new ViewGroup.LayoutParams(-1,-1)); AlphaAnimation aa=new AlphaAnimation(1,0); aa.setDuration(1500); aa.setAnimationListener(new Animation.AnimationListener(){ public void onAnimationStart(Animation a){} public void onAnimationRepeat(Animation a){} public void onAnimationEnd(Animation a){ ((ViewGroup)flash.getParent()).removeView(flash);} }); flash.startAnimation(aa); }
    void reactTap(){ if(stage==1) showSpeech(expr==1?"Mii：ふふ、見つめすぎだよ…？":"Mii：今日も会いに来てくれてありがとう！"); else showSpeech(stage==2?"Mii：この姿、どうかな…？":"Mii：もっと近くで見ててね"); updateImage(); pulse(charView); }
    void updateStreamAll(){ checkUnlock(); updateImage(); makeButtons(); if(walletView!=null)walletView.setText("所持金："+yen(wallet)); if(totalView!=null)totalView.setText("累計投げ銭："+yen(totalDonated)); if(affView!=null)affView.setText("好感度："+affection); if(unlockView!=null)unlockView.setText("解放：￥240 / ￥1,000"+(unlocked[2]?" / ￥5,000":" / 🔒￥5,000")+(unlocked[3]?" / ￥10,000":" / 🔒￥10,000")+(unlocked[4]?" / ￥50,000":" / 🔒￥50,000")); if(commentView!=null)commentView.setText("コメント\n・"+String.join("\n・",comments)); }
    void updateImage(){ if(charView==null)return; String name="stage1_idle"; if(stage==1&&expr==1)name="stage1_blush"; else if(stage==2)name="stage2_idle"; else if(stage>=3)name="stage3_idle"; charView.setImageResource(res(name)); }
    void showSpeech(String s){ if(speechView!=null){ speechView.setText(s); pulse(speechView); } }
    void addComment(String s){ ArrayList<String> list=new ArrayList<>(); list.add(s); for(String c:comments)list.add(c); while(list.size()>4)list.remove(list.size()-1); comments=list.toArray(new String[0]); }
    void pulse(View v){ if(v==null)return; ScaleAnimation s=new ScaleAnimation(1f,1.035f,1f,1.035f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f); s.setDuration(170); s.setRepeatCount(1); s.setRepeatMode(Animation.REVERSE); v.startAnimation(s); }
    void pulseLoop(View v){ ScaleAnimation s=new ScaleAnimation(1f,1.035f,1f,1.035f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f); s.setDuration(1150); s.setRepeatCount(Animation.INFINITE); s.setRepeatMode(Animation.REVERSE); v.startAnimation(s); }
    void startFloat(){ if(charView==null)return; TranslateAnimation t=new TranslateAnimation(0,0,-5,5); t.setDuration(1800); t.setRepeatCount(Animation.INFINITE); t.setRepeatMode(Animation.REVERSE); charView.startAnimation(t); }
    @Override public void onBackPressed(){ if(inStream||inMini) showTitle(); else super.onBackPressed(); }
}
