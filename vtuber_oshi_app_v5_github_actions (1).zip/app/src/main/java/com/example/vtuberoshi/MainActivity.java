package com.example.vtuberoshi;

import android.app.*;import android.os.*;import android.content.*;import android.content.SharedPreferences;import android.graphics.*;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity{
    OshiView oshiView; SharedPreferences prefs; int currentStage=1,currentFace=0,total=0,maxButton=1000; String[] faces={"通常","笑顔","照れ","驚き"};
    TextView totalText,stageText,lineText; LinearLayout buttonBox; static final int PICK=909;
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("oshi_v5",0); load(); buildUi();}
    void load(){total=prefs.getInt("total",0); currentStage=prefs.getInt("stage",1); maxButton=prefs.getInt("maxButton",1000); currentFace=prefs.getInt("face",0);} 
    void save(){prefs.edit().putInt("total",total).putInt("stage",currentStage).putInt("maxButton",maxButton).putInt("face",currentFace).apply();}
    void buildUi(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(15,5,28));
        LinearLayout main=new LinearLayout(this); main.setOrientation(LinearLayout.HORIZONTAL); root.addView(main,new FrameLayout.LayoutParams(-1,-1));
        oshiView=new OshiView(this); oshiView.stage=currentStage; oshiView.face=currentFace; oshiView.setOnClickListener(v->{ currentFace=(currentFace+1)%faces.length; oshiView.face=currentFace; save(); updateTexts("表情: "+faces[currentFace]); oshiView.invalidate(); });
        main.addView(oshiView,new LinearLayout.LayoutParams(0,-1,7));
        ScrollView scroll=new ScrollView(this); LinearLayout side=new LinearLayout(this); side.setOrientation(LinearLayout.VERTICAL); side.setPadding(dp(12),dp(12),dp(12),dp(12)); scroll.addView(side); main.addView(scroll,new LinearLayout.LayoutParams(0,-1,3));
        TextView title=label("九尾VTuber 配信",24,true); side.addView(title);
        totalText=label("",18,true); side.addView(totalText); stageText=label("",16,false); side.addView(stageText); lineText=label("",15,false); side.addView(lineText);
        buttonBox=new LinearLayout(this); buttonBox.setOrientation(LinearLayout.VERTICAL); side.addView(buttonBox);
        Button change=btn("現在の立ち絵を画像変更"); change.setOnClickListener(v->pickImage()); side.addView(change);
        Button reset=btn("データリセット"); reset.setOnClickListener(v->{prefs.edit().clear().apply(); total=0;currentStage=1;maxButton=1000;currentFace=0;oshiView.stage=1;oshiView.face=0;updateTexts("リセットしたよ");}); side.addView(reset);
        setContentView(root); updateTexts("配信開始！");
    }
    Button btn(String s){Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setAllCaps(false); b.setPadding(8,8,8,8); return b;}
    TextView label(String s,int size,boolean bold){TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); if(bold)t.setTypeface(Typeface.DEFAULT_BOLD); t.setPadding(0,6,0,6); return t;}
    void updateTexts(String msg){
        totalText.setText("累計: "+total+"円"); stageText.setText("Stage "+currentStage+" / 上限: "+maxButton+"円"); lineText.setText(msg+"\nタップで表情変更: "+faces[currentFace]);
        buttonBox.removeAllViews(); addMoneyButton(240); addMoneyButton(1000); if(maxButton>=5000)addMoneyButton(5000); if(maxButton>=10000)addMoneyButton(10000); if(maxButton>=50000)addMoneyButton(50000);
        oshiView.stage=currentStage; oshiView.face=currentFace; oshiView.invalidate();
    }
    void addMoneyButton(int amount){Button b=btn(amount+"円 投げ銭"); b.setOnClickListener(v->donate(amount)); buttonBox.addView(b,new LinearLayout.LayoutParams(-1,dp(56)));}
    void donate(int amount){ total+=amount; String msg=amount+"円ありがとう！"; int oldStage=currentStage; if(total>=50000){maxButton=50000; currentStage=4; msg="最終上限解放！特別な姿に…！";} else if(total>=10000){maxButton=10000; currentStage=3; msg="10000円解放！立ち絵が進化！";} else if(total>=5000){maxButton=5000; currentStage=2; msg="5000円解放！新しい姿になったよ！";} if(currentStage!=oldStage){currentFace=0; oshiView.flash();} save(); updateTexts(msg); }
    void pickImage(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i,PICK); }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==PICK&&c==RESULT_OK&&d!=null){Uri u=d.getData(); getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION); prefs.edit().putString("img_s"+currentStage+"_f"+currentFace,u.toString()).apply(); oshiView.reload(); updateTexts("画像を変更したよ！");}}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);} 

    class OshiView extends View{ Paint p=new Paint(1); int stage=1,face=0; long flashStart=0; Map<String,Bitmap> cache=new HashMap<>();
        OshiView(Context c){super(c);} void reload(){cache.clear();} void flash(){flashStart=System.currentTimeMillis(); invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c); int w=getWidth(),h=getHeight();
            LinearGradient bg=new LinearGradient(0,0,w,h,new int[]{Color.rgb(35,8,55),Color.rgb(96,35,128),Color.rgb(20,8,35)},null,Shader.TileMode.CLAMP); p.setShader(bg); c.drawRect(0,0,w,h,p); p.setShader(null);
            p.setColor(Color.argb(70,255,255,255)); for(int i=0;i<18;i++){float x=(i*97+stage*41)%Math.max(1,w);float y=(i*53+face*70)%Math.max(1,h); c.drawCircle(x,y,dp(2+(i%4)),p);} 
            Bitmap bm=getCustom(); if(bm!=null){Rect src=new Rect(0,0,bm.getWidth(),bm.getHeight()); int size=(int)(h*0.86); Rect dst=new Rect(w/2-size/2,h/2-size/2,w/2+size/2,h/2+size/2); c.drawBitmap(bm,src,dst,p);} else drawDefault(c,w,h);
            p.setColor(Color.argb(185,0,0,0)); c.drawRoundRect(dp(16),h-dp(92),w-dp(16),h-dp(18),dp(18),dp(18),p); p.setColor(Color.WHITE); p.setTextSize(dp(24)); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(stageLine(),dp(36),h-dp(46),p);
            if(System.currentTimeMillis()-flashStart<1400){float t=(System.currentTimeMillis()-flashStart)/1400f; p.setColor(Color.argb((int)(160*(1-t)),255,210,255)); c.drawRect(0,0,w,h,p); p.setColor(Color.argb((int)(220*(1-t)),255,255,255)); p.setTextSize(dp(38)); p.setTextAlign(Paint.Align.CENTER); c.drawText("上限解放！",w/2,h/2,p); p.setTextAlign(Paint.Align.LEFT); postInvalidateDelayed(16);} }
        Bitmap getCustom(){String key="img_s"+stage+"_f"+face; String uri=prefs.getString(key,null); if(uri==null)return null; if(cache.containsKey(key))return cache.get(key); try{Bitmap b=BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(uri))); cache.put(key,b); return b;}catch(Exception e){return null;}}
        String stageLine(){String[] l={"来てくれてありがとう！","もっと近くで応援してね","特別な配信、始めよっか","最後まで一緒にいてね"}; return l[Math.max(0,Math.min(stage-1,l.length-1))]+"  / "+faces[face];}
        void drawDefault(Canvas c,int w,int h){float cx=w*0.5f, cy=h*0.52f; p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(90,210,120,255)); for(int i=0;i<9;i++){float a=(float)(Math.PI*2*i/9); c.drawOval(cx+(float)Math.cos(a)*dp(75)-dp(28),cy+(float)Math.sin(a)*dp(45)-dp(85),cx+(float)Math.cos(a)*dp(75)+dp(28),cy+(float)Math.sin(a)*dp(45)+dp(85),p);} 
            p.setColor(stage==1?Color.rgb(135,70,200):stage==2?Color.rgb(180,85,220):stage==3?Color.rgb(220,100,210):Color.rgb(255,120,190)); c.drawOval(cx-dp(95),cy-dp(120),cx+dp(95),cy+dp(145),p);
            p.setColor(Color.rgb(255,225,245)); c.drawCircle(cx,cy-dp(95),dp(72),p); p.setColor(Color.rgb(95,32,135)); c.drawPath(tri(cx-dp(48),cy-dp(145),-1),p); c.drawPath(tri(cx+dp(48),cy-dp(145),1),p);
            p.setColor(Color.rgb(30,5,45)); c.drawCircle(cx-dp(28),cy-dp(100),dp(8),p); c.drawCircle(cx+dp(28),cy-dp(100),dp(8),p); p.setColor(Color.rgb(255,100,190)); if(face==2)c.drawCircle(cx,cy-dp(76),dp(14),p); else c.drawRoundRect(cx-dp(18),cy-dp(74),cx+dp(18),cy-dp(64),dp(6),dp(6),p);
            p.setColor(Color.WHITE); p.setTextSize(dp(20)); p.setTextAlign(Paint.Align.CENTER); c.drawText("Stage "+stage+"  "+faces[face],cx,cy+dp(190),p); p.setTextAlign(Paint.Align.LEFT);}
        Path tri(float x,float y,int dir){Path path=new Path(); path.moveTo(x,y-dp(48)); path.lineTo(x+dir*dp(46),y+dp(30)); path.lineTo(x-dir*dp(22),y+dp(18)); path.close(); return path;}
    }
}
