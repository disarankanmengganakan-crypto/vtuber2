package com.kokon.vtuberoshi.v10;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    int totalDonated = 0, affection = 0, stage = 1, expr = 0, wallet = 0, selectedBet = 100;
    ImageView charView, bgView;
    TextView speechBubble, totalView, affView, walletView, unlockView, commentView, scratchResult, slotMsg;
    GridLayout moneyGrid;
    LinearLayout betRow;
    ImageView[] slotImages = new ImageView[3];
    boolean inSubScreen = false;
    Random rnd = new Random();
    int[] amounts = {240, 1000, 5000, 10000, 50000};
    boolean[] unlocked = {true, true, false, false, false};
    String[] comments = {"Miiちゃん今日もかわいい！", "配信部屋めっちゃ似合ってる", "応援してるよ！"};
    int[] slotDrawables = {R.drawable.slot_face1, R.drawable.slot_face2, R.drawable.slot_face3, R.drawable.slot_face4, R.drawable.slot_cat, R.drawable.slot_heart, R.drawable.slot_fire, R.drawable.slot_syringe};
    String[] slotNames = {"Mii", "先生", "メル", "おかゆ", "猫", "ハート", "狐火", "注射器"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        showTitle();
    }

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    String yen(int n) { return "￥" + NumberFormat.getNumberInstance().format(n); }
    TextView tv(String s, int sp, int c, int style) { TextView v = new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(c); v.setTypeface(Typeface.DEFAULT, style); v.setPadding(dp(6), dp(4), dp(6), dp(4)); return v; }
    GradientDrawable round(int color, int strokeColor, int strokeWidth, int radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); if (strokeWidth > 0) g.setStroke(dp(strokeWidth), strokeColor); return g; }
    Button btn(String text, int sp) { Button b = new Button(this); b.setText(text); b.setTextSize(sp); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false); b.setSingleLine(false); b.setPadding(dp(4), 0, dp(4), 0); b.setTextColor(0xff26142f); b.setBackground(round(0xfff7f0fb, 0xffff5b79, 2, 16)); return b; }

    public void showTitle() {
        inSubScreen = false;
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(Color.rgb(12, 0, 24));
        ImageView titleBg = new ImageView(this); titleBg.setImageResource(R.drawable.title_bg); titleBg.setScaleType(ImageView.ScaleType.CENTER_CROP); root.addView(titleBg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this); shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x77000000, 0x11000000, 0xaa080012})); root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.title_logo); logo.setScaleType(ImageView.ScaleType.FIT_CENTER); FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(dp(520), dp(165)); logoLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL; logoLp.topMargin = dp(6); root.addView(logo, logoLp); pulseLoop(logo);
        for (int i = 0; i < 4; i++) { final int idx = i; TextView hot = tv(idx == 0 ? "Mii" : "準備中", 13, Color.WHITE, Typeface.BOLD); hot.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL); hot.setShadowLayer(dp(5), 0, 0, Color.BLACK); hot.setBackgroundColor(Color.TRANSPARENT); FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels / 4, -1); hp.leftMargin = hp.width * i; root.addView(hot, hp); hot.setOnClickListener(v -> { if (idx == 0) buildStream(); else Toast.makeText(this, "キャラ"+(idx+1)+"は準備中です", Toast.LENGTH_SHORT).show(); }); }
        LinearLayout menu = new LinearLayout(this); menu.setOrientation(LinearLayout.HORIZONTAL); menu.setPadding(dp(14), dp(8), dp(14), dp(8)); menu.setBackground(round(0xaa12001f, 0x88ff74b7, 1, 22)); FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(620), dp(78)); mp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL; mp.bottomMargin = dp(12); root.addView(menu, mp);
        Button live = btn("配信を見る", 17); live.setOnClickListener(v -> buildStream()); Button mini = btn("ミニゲームで稼ぐ", 17); mini.setOnClickListener(v -> buildMiniGame()); menu.addView(live, new LinearLayout.LayoutParams(0, -1, 1)); Space sp = new Space(this); menu.addView(sp, new LinearLayout.LayoutParams(dp(12), -1)); menu.addView(mini, new LinearLayout.LayoutParams(0, -1, 1));
        setContentView(root);
    }

    public void buildStream() {
        inSubScreen = true;
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(Color.rgb(20, 0, 28));
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.HORIZONTAL); main.setPadding(dp(8), dp(6), dp(8), dp(6)); root.addView(main, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout live = new FrameLayout(this); main.addView(live, new LinearLayout.LayoutParams(0, -1, 7));
        bgView = new ImageView(this); bgView.setScaleType(ImageView.ScaleType.CENTER_CROP); bgView.setImageResource(R.drawable.bg_stream); live.addView(bgView, new FrameLayout.LayoutParams(-1, -1));
        charView = new ImageView(this); charView.setScaleType(ImageView.ScaleType.FIT_CENTER); live.addView(charView, new FrameLayout.LayoutParams(-1, -1)); live.setOnClickListener(v -> { expr = (expr + 1) % 2; reactTap(); });
        TextView liveTxt = tv("● LIVE", 24, Color.WHITE, Typeface.BOLD); liveTxt.setShadowLayer(dp(8),0,0,Color.BLACK); FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2); lp.leftMargin = dp(16); lp.topMargin = dp(8); live.addView(liveTxt, lp);
        TextView back = tv("← TITLE", 13, Color.WHITE, Typeface.BOLD); back.setShadowLayer(dp(6),0,0,Color.BLACK); back.setBackground(round(0x66000000, 0x66ffffff, 1, 14)); FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2); bp.gravity = Gravity.TOP | Gravity.RIGHT; bp.topMargin = dp(8); bp.rightMargin = dp(8); live.addView(back, bp); back.setOnClickListener(v -> showTitle());
        TextView tapHint = tv("TAPで表情変更", 12, 0xffffe6ef, Typeface.BOLD); tapHint.setShadowLayer(dp(6),0,0,Color.BLACK); FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2); hp.leftMargin = dp(16); hp.gravity = Gravity.BOTTOM | Gravity.LEFT; hp.bottomMargin = dp(10); live.addView(tapHint, hp);
        speechBubble = tv("Mii：今日も会いに来てくれてありがとう！", 15, Color.WHITE, Typeface.BOLD); speechBubble.setGravity(Gravity.CENTER); speechBubble.setBackground(round(0xbb180022, 0xaaff7db7, 2, 24)); FrameLayout.LayoutParams sbp = new FrameLayout.LayoutParams(dp(360), dp(82)); sbp.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL; sbp.rightMargin = dp(22); live.addView(speechBubble, sbp);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); main.addView(scroll, new LinearLayout.LayoutParams(0, -1, 3));
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(12), dp(4), dp(8), dp(12)); scroll.addView(panel, new ScrollView.LayoutParams(-1, -2));
        TextView titleView = tv("Mii 推しライブ V10", 20, Color.WHITE, Typeface.BOLD); titleView.setGravity(Gravity.CENTER); panel.addView(titleView, new LinearLayout.LayoutParams(-1, -2));
        walletView = tv("", 16, 0xfffff1a6, Typeface.BOLD); totalView = tv("", 15, Color.WHITE, Typeface.BOLD); affView = tv("", 15, Color.WHITE, Typeface.BOLD); unlockView = tv("", 11, 0xffffd6e2, Typeface.BOLD); panel.addView(walletView); panel.addView(totalView); panel.addView(affView); panel.addView(unlockView);
        commentView = tv("", 12, 0xff26142f, Typeface.NORMAL); commentView.setBackground(round(0xeef2e8f5, 0, 0, 16)); panel.addView(commentView, new LinearLayout.LayoutParams(-1, dp(86)));
        Button goMini = btn("ミニゲームで稼ぐ", 12); goMini.setOnClickListener(v -> buildMiniGame()); panel.addView(goMini, new LinearLayout.LayoutParams(-1, dp(42)));
        TextView donateTitle = tv("投げ銭", 14, 0xffffd6e2, Typeface.BOLD); donateTitle.setGravity(Gravity.CENTER); panel.addView(donateTitle);
        moneyGrid = new GridLayout(this); moneyGrid.setColumnCount(2); moneyGrid.setPadding(0, dp(2), 0, dp(2)); panel.addView(moneyGrid, new LinearLayout.LayoutParams(-1, -2));
        Button reset = btn("RESET", 11); reset.setOnClickListener(v -> { totalDonated=0; affection=0; stage=1; expr=0; wallet=0; selectedBet=100; Arrays.fill(unlocked,false); unlocked[0]=unlocked[1]=true; updateAll(); }); panel.addView(reset, new LinearLayout.LayoutParams(-1, dp(38)));
        setContentView(root); updateAll(); startFloat();
    }

    public void buildMiniGame() {
        inSubScreen = true;
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(0xff180021);
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.HORIZONTAL); main.setPadding(dp(12), dp(10), dp(12), dp(10)); root.addView(main, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL); left.setPadding(dp(10), dp(4), dp(10), dp(4)); main.addView(left, new LinearLayout.LayoutParams(0, -1, 7));
        TextView title = tv("ミニゲームで稼ぐ", 26, Color.WHITE, Typeface.BOLD); title.setGravity(Gravity.CENTER); left.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView desc = tv("スクラッチでコツコツ稼いで、スロットで大勝負！", 14, 0xffffd6e2, Typeface.BOLD); desc.setGravity(Gravity.CENTER); left.addView(desc);
        LinearLayout games = new LinearLayout(this); games.setOrientation(LinearLayout.HORIZONTAL); left.addView(games, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout scratch = cardBox("スクラッチ", "1マス削って報酬GET"); games.addView(scratch, new LinearLayout.LayoutParams(0, -1, 1));
        Button scratchBtn = btn("削る！", 24); scratch.addView(scratchBtn, new LinearLayout.LayoutParams(-1, 0, 1)); scratchResult = tv("未挑戦", 18, Color.WHITE, Typeface.BOLD); scratchResult.setGravity(Gravity.CENTER); scratch.addView(scratchResult, new LinearLayout.LayoutParams(-1, dp(54))); scratchBtn.setOnClickListener(v -> playScratch());
        Space space = new Space(this); games.addView(space, new LinearLayout.LayoutParams(dp(12), -1));
        LinearLayout slot = cardBox("推しスロット", "BETして絵柄を揃えよう"); games.addView(slot, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout reels = new LinearLayout(this); reels.setOrientation(LinearLayout.HORIZONTAL); slot.addView(reels, new LinearLayout.LayoutParams(-1, 0, 1));
        for (int i=0;i<3;i++) { slotImages[i] = new ImageView(this); slotImages[i].setScaleType(ImageView.ScaleType.FIT_CENTER); slotImages[i].setImageResource(slotDrawables[i]); slotImages[i].setBackground(round(0x33100020, 0x88b44cff, 1, 18)); LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, -1, 1); ip.setMargins(dp(4),dp(4),dp(4),dp(4)); reels.addView(slotImages[i], ip); }
        betRow = new LinearLayout(this); betRow.setOrientation(LinearLayout.HORIZONTAL); slot.addView(betRow, new LinearLayout.LayoutParams(-1, dp(42))); int[] bets = {100,500,1000}; for(int bet:bets){ Button b=btn(yen(bet),11); b.setOnClickListener(v->{ selectedBet=bet; refreshMiniLabels(); }); betRow.addView(b, new LinearLayout.LayoutParams(0,-1,1)); }
        Button spin=btn("SPIN", 18); spin.setOnClickListener(v -> playSlot()); slot.addView(spin, new LinearLayout.LayoutParams(-1, dp(50))); slotMsg = tv("BETを選んでSPIN！", 15, Color.WHITE, Typeface.BOLD); slotMsg.setGravity(Gravity.CENTER); slot.addView(slotMsg, new LinearLayout.LayoutParams(-1, dp(46)));
        LinearLayout right = new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL); right.setPadding(dp(12), dp(8), dp(8), dp(8)); right.setBackground(round(0x66100020, 0x55ff7db7, 1, 22)); main.addView(right, new LinearLayout.LayoutParams(0, -1, 3));
        TextView menuTitle = tv("MENU", 22, Color.WHITE, Typeface.BOLD); menuTitle.setGravity(Gravity.CENTER); right.addView(menuTitle); walletView = tv("", 18, 0xfffff1a6, Typeface.BOLD); totalView = tv("", 14, Color.WHITE, Typeface.BOLD); affView = tv("", 14, Color.WHITE, Typeface.BOLD); right.addView(walletView); right.addView(totalView); right.addView(affView);
        Button goStream = btn("配信へ戻る", 15); goStream.setOnClickListener(v -> buildStream()); right.addView(goStream, new LinearLayout.LayoutParams(-1, dp(48))); Button goTitle = btn("タイトルへ", 15); goTitle.setOnClickListener(v -> showTitle()); right.addView(goTitle, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView hint = tv("当たり目安\n同じ絵柄3つ：5〜10倍\n2つ揃い：2倍\nハズレ：没収", 12, 0xffffd6e2, Typeface.BOLD); right.addView(hint, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root); refreshMiniLabels();
    }
    LinearLayout cardBox(String title, String sub) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(10), dp(8), dp(10), dp(8)); box.setBackground(round(0x55260034, 0x77ff7db7, 2, 22));
        TextView t = tv(title, 21, Color.WHITE, Typeface.BOLD); t.setGravity(Gravity.CENTER); box.addView(t);
        TextView s = tv(sub, 12, 0xffffd6e2, Typeface.BOLD); s.setGravity(Gravity.CENTER); box.addView(s);
        return box;
    }
    void playScratch() {
        int r = rnd.nextInt(100); int gain;
        if (r < 5) gain = 1000; else if (r < 20) gain = 500; else if (r < 55) gain = 200; else gain = 80 + rnd.nextInt(71);
        wallet += gain; scratchResult.setText("+" + yen(gain) + " GET!"); addComment("あなた：スクラッチで" + yen(gain) + "稼いだ！"); flashText("SCRATCH +" + yen(gain)); refreshMiniLabels();
    }
    void playSlot() {
        if (wallet < selectedBet) { Toast.makeText(this, "所持金が足りないよ。まずはスクラッチ！", Toast.LENGTH_SHORT).show(); return; }
        wallet -= selectedBet; int[] result = new int[3];
        for (int i=0;i<3;i++) { result[i] = rnd.nextInt(slotDrawables.length); slotImages[i].setImageResource(slotDrawables[result[i]]); pulse(slotImages[i]); }
        int reward = 0; String msg = "ハズレ…";
        if (result[0] == result[1] && result[1] == result[2]) { reward = selectedBet * (result[0] == 0 ? 10 : 5); msg = slotNames[result[0]] + " 3つ揃い！"; }
        else if (result[0] == result[1] || result[1] == result[2] || result[0] == result[2]) { reward = selectedBet * 2; msg = "2つ揃い！"; }
        wallet += reward; slotMsg.setText(reward > 0 ? msg + " +" + yen(reward) : msg + " -" + yen(selectedBet)); addComment("スロット：" + (reward>0 ? "+"+yen(reward) : "ハズレ"));
        if (reward > 0) flashText("JACKPOT!"); refreshMiniLabels();
    }
    void refreshMiniLabels() {
        if (walletView != null) walletView.setText("所持金：" + yen(wallet));
        if (totalView != null) totalView.setText("累計投げ銭：" + yen(totalDonated));
        if (affView != null) affView.setText("好感度：" + affection);
        if (betRow != null) { for (int i=0;i<betRow.getChildCount();i++) { Button b=(Button)betRow.getChildAt(i); int bet = (i==0?100:(i==1?500:1000)); b.setText((selectedBet==bet?"▶ ":"") + yen(bet)); } }
    }
    void makeButtons() {
        if (moneyGrid == null) return; moneyGrid.removeAllViews();
        for (int i = 0; i < amounts.length; i++) { final int a = amounts[i]; boolean can = unlocked[i] && wallet >= a; Button bt = btn((unlocked[i] ? yen(a) : "🔒"+yen(a)) + (unlocked[i] && wallet<a ? "\n不足" : ""), 10); bt.setEnabled(can); bt.setAlpha(can ? 1f : 0.58f); bt.setOnClickListener(v -> donate(a)); GridLayout.LayoutParams gp = new GridLayout.LayoutParams(); gp.width = 0; gp.height = dp(48); gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); gp.setMargins(dp(3), dp(3), dp(3), dp(3)); moneyGrid.addView(bt, gp); }
    }
    void donate(int a) {
        if (wallet < a) { Toast.makeText(this, "所持金不足！ミニゲームで稼いでから貢ごう", Toast.LENGTH_SHORT).show(); return; }
        wallet -= a; totalDonated += a; affection += Math.max(1, a / 120); setSpeech("Mii：" + yen(a) + "ありがとう！大事にするね！"); addComment("あなた：" + yen(a) + " 投げ銭！"); checkUnlock(); pulse(charView); updateAll();
    }
    void checkUnlock() {
        int old = stage;
        if (totalDonated >= 10000) { unlocked[3] = true; stage = 3; } else if (totalDonated >= 5000) { unlocked[2] = true; stage = 2; }
        if (totalDonated >= 50000) unlocked[4] = true; if (stage > old) unlockEffect();
    }
    void unlockEffect() { setSpeech(stage == 2 ? "Mii：新しい姿、見せちゃうね…！" : "Mii：ここまで応援してくれたんだね…♡"); flashText("STAGE UP!"); }
    void reactTap() { if (stage == 1) setSpeech(expr == 1 ? "Mii：ふふ、見つめすぎだよ…？" : "Mii：今日も会いに来てくれてありがとう！"); else setSpeech(stage == 2 ? "Mii：この姿、どうかな…？" : "Mii：もっと近くで見ててね"); updateImage(); pulse(charView); }
    void setSpeech(String s) { if (speechBubble != null) speechBubble.setText(s); }
    void updateAll() {
        checkUnlock(); updateImage(); makeButtons(); refreshMiniLabels();
        if (unlockView != null) unlockView.setText("解放：￥240 / ￥1,000" + (unlocked[2]?" / ￥5,000":" / 🔒￥5,000") + (unlocked[3]?" / ￥10,000":" / 🔒￥10,000") + (unlocked[4]?" / ￥50,000":" / 🔒￥50,000"));
        if (commentView != null) commentView.setText("コメント\n・" + String.join("\n・", comments));
    }
    void updateImage() { if (charView == null) return; int res = R.drawable.stage1_idle; if (stage == 1 && expr == 1) res = R.drawable.stage1_blush; else if (stage == 2) res = R.drawable.stage2_idle; else if (stage >= 3) res = R.drawable.stage3_idle; charView.setImageResource(res); }
    void addComment(String s) { ArrayList<String> list = new ArrayList<>(); list.add(s); for (String c : comments) list.add(c); while (list.size() > 4) list.remove(list.size() - 1); comments = list.toArray(new String[0]); }
    void pulse(View v) { if (v==null) return; ScaleAnimation s = new ScaleAnimation(1f,1.04f,1f,1.04f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f); s.setDuration(170); s.setRepeatCount(1); s.setRepeatMode(Animation.REVERSE); v.startAnimation(s); }
    void pulseLoop(View v) { ScaleAnimation s = new ScaleAnimation(1f,1.035f,1f,1.035f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f); s.setDuration(1150); s.setRepeatCount(Animation.INFINITE); s.setRepeatMode(Animation.REVERSE); v.startAnimation(s); }
    void startFloat() { if (charView==null) return; TranslateAnimation t = new TranslateAnimation(0,0,-5,5); t.setDuration(1800); t.setRepeatCount(Animation.INFINITE); t.setRepeatMode(Animation.REVERSE); charView.startAnimation(t); }
    void flashText(String text) { final TextView flash = tv(text, 38, 0xffffd1e6, Typeface.BOLD); flash.setGravity(Gravity.CENTER); flash.setShadowLayer(dp(12),0,0,0xffff2d80); addContentView(flash, new ViewGroup.LayoutParams(-1, -1)); AlphaAnimation aa = new AlphaAnimation(1, 0); aa.setDuration(1300); aa.setAnimationListener(new Animation.AnimationListener(){ public void onAnimationStart(Animation a){} public void onAnimationRepeat(Animation a){} public void onAnimationEnd(Animation a){ if (flash.getParent()!=null) ((ViewGroup)flash.getParent()).removeView(flash); }}); flash.startAnimation(aa); }
    @Override public void onBackPressed() { if (inSubScreen) showTitle(); else super.onBackPressed(); }
}
