package com.example.vtubercardbattle;

import android.app.*;import android.os.*;import android.view.*;import android.widget.*;import android.graphics.*;import android.graphics.drawable.*;import android.content.*;import android.net.*;import android.provider.Settings;import java.util.*;

public class MainActivity extends Activity{
    BattleView battle; TextView status; int pending=-1; SharedPreferences prefs;
    static final int PICK=77;
    public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("custom",0); buildUi();}
    void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(16,10,16,10); root.setBackgroundColor(Color.rgb(22,0,38));
        TextView title=new TextView(this); title.setText("九尾カードバトル V3  写真カスタム版"); title.setTextColor(Color.WHITE); title.setTextSize(24); title.setTypeface(Typeface.DEFAULT_BOLD); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        battle=new BattleView(this,prefs); root.addView(battle,new LinearLayout.LayoutParams(-1,0,1));
        status=new TextView(this); status.setText("カードをタップ→写真変更でスマホ内の画像に差し替えできるよ。マス画像も変更OK！"); status.setTextColor(Color.WHITE); status.setTextSize(16); status.setPadding(8,6,8,6); root.addView(status,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER); bar.setOrientation(LinearLayout.HORIZONTAL);
        String[] names={"写真変更","味方マス変更","敵マス変更","BATTLE","RESET"};
        for(String n:names){Button btn=new Button(this); btn.setText(n); btn.setTextSize(14); btn.setAllCaps(false); btn.setOnClickListener(v->onBtn(((Button)v).getText().toString())); bar.addView(btn,new LinearLayout.LayoutParams(0,58,1));}
        root.addView(bar,new LinearLayout.LayoutParams(-1,-2)); setContentView(root);
    }
    void onBtn(String s){
        if(s.startsWith("写真")){ if(battle.selectedCard<0){toast("先に変更したい味方カードをタップしてね");return;} pending=battle.selectedCard; pick(); }
        else if(s.startsWith("味方")){pending=100;pick();}
        else if(s.startsWith("敵")){pending=101;pick();}
        else if(s.startsWith("BATTLE")){battle.nextTurn(); status.setText(battle.message);}
        else {battle.reset(); status.setText("リセットしたよ。好きな場所に味方カードを置いてね！");}
    }
    void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,PICK);} 
    public void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==PICK&&c==RESULT_OK&&d!=null){Uri u=d.getData(); try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception e){} if(pending>=0&&pending<5)prefs.edit().putString("card"+pending,u.toString()).apply(); if(pending==100)prefs.edit().putString("allyTile",u.toString()).apply(); if(pending==101)prefs.edit().putString("enemyTile",u.toString()).apply(); battle.reload(); toast("画像を差し替えたよ！");}}
    void toast(String m){Toast.makeText(this,m,Toast.LENGTH_SHORT).show();}

    public static class Unit{String name;int hp,max,atk;boolean ally;int cell;Unit(String n,int h,int a,boolean al,int c){name=n;hp=max=h;atk=a;ally=al;cell=c;}}
    public static class BattleView extends View{Paint p=new Paint(1);ArrayList<Unit> units=new ArrayList<>();SharedPreferences prefs;Bitmap[] cardBmp=new Bitmap[5];Bitmap allyTile,enemyTile;int selectedCard=0,turn=1;String message="";String[] names={"紫月","巫女狐","尾火","白狐","幻狐"};int[] hp={42,36,28,50,32},atk={16,13,21,10,18};
        BattleView(Context c,SharedPreferences pr){super(c);prefs=pr;setOnClickListener(v->{});reload();reset();}
        void reload(){for(int i=0;i<5;i++)cardBmp[i]=load("card"+i); allyTile=load("allyTile"); enemyTile=load("enemyTile"); invalidate();}
        Bitmap load(String k){try{String s=prefs.getString(k,null); if(s==null)return null; return BitmapFactory.decodeStream(getContext().getContentResolver().openInputStream(Uri.parse(s)));}catch(Exception e){return null;}}
        void reset(){units.clear(); for(int i=0;i<5;i++)units.add(new Unit(names[i],hp[i],atk[i],true,4+i%5)); units.add(new Unit("ゾンビ",45,9,false,2)); units.add(new Unit("骨兵",55,12,false,4)); units.add(new Unit("魔王",70,15,false,6)); turn=1;message="TURN 1：BATTLEで攻撃開始！ カードタップで選択できるよ";invalidate();}
        protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight(); p.setColor(Color.rgb(36,4,58));c.drawRect(0,0,w,h,p); drawStars(c,w,h); int top=20,grid=3; int size=Math.min((w/2-70)/3,(h-70)/3); int gap=8; int ex=40, ax=w/2+30; drawGrid(c,ex,top,size,gap,false); drawGrid(c,ax,top,size,gap,true); for(Unit u:units)drawUnit(c,u,u.ally?ax:ex,top,size,gap); p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(24);p.setColor(Color.WHITE);c.drawText("ENEMY",ex+size*3/2+gap,top+size*3+45,p);c.drawText("ALLY",ax+size*3/2+gap,top+size*3+45,p); p.setTextSize(22);c.drawText("TURN "+turn,w/2,top+30,p);}
        void drawStars(Canvas c,int w,int h){p.setColor(Color.argb(60,180,70,255));for(int i=0;i<45;i++)c.drawCircle((i*83)%w,(i*47)%h,3+(i%4),p);} 
        void drawGrid(Canvas c,int x,int y,int s,int g,boolean ally){for(int r=0;r<3;r++)for(int col=0;col<3;col++){RectF rr=new RectF(x+col*(s+g),y+r*(s+g),x+col*(s+g)+s,y+r*(s+g)+s);Bitmap tile=ally?allyTile:enemyTile; if(tile!=null)c.drawBitmap(tile,null,rr,p); else {p.setColor(ally?Color.rgb(90,50,140):Color.rgb(140,55,85));c.drawRoundRect(rr,18,18,p);} p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.argb(160,255,255,255));c.drawRoundRect(rr,18,18,p);p.setStyle(Paint.Style.FILL);}}
        void drawUnit(Canvas c,Unit u,int x,int y,int s,int g){int col=u.cell%3,row=u.cell/3;RectF rr=new RectF(x+col*(s+g)+7,y+row*(s+g)+7,x+col*(s+g)+s-7,y+row*(s+g)+s-7); if(u.ally){int idx=Arrays.asList(names).indexOf(u.name);Bitmap b=idx>=0?cardBmp[idx]:null;if(b!=null)c.drawBitmap(b,null,rr,p);else drawCute(c,rr,u.name,Color.rgb(196,100,255));} else drawCute(c,rr,u.name,Color.rgb(255,125,145)); p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(14);c.drawText(u.name,rr.centerX(),rr.bottom-22,p);p.setTextSize(12);c.drawText("HP"+u.hp+" ATK"+u.atk,rr.centerX(),rr.bottom-6,p); if(u.ally&&selectedCard==Arrays.asList(names).indexOf(u.name)){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6);p.setColor(Color.YELLOW);c.drawRoundRect(rr,20,20,p);p.setStyle(Paint.Style.FILL);}}
        void drawCute(Canvas c,RectF rr,String t,int color){p.setColor(color);c.drawRoundRect(rr,22,22,p);p.setColor(Color.argb(180,255,255,255));c.drawCircle(rr.centerX(),rr.centerY()-8,Math.min(rr.width(),rr.height())/4,p);p.setColor(Color.rgb(40,0,55));p.setTextSize(24);p.setTextAlign(Paint.Align.CENTER);c.drawText(t.substring(0,1),rr.centerX(),rr.centerY(),p);} 
        public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;int w=getWidth(),h=getHeight();int s=Math.min((w/2-70)/3,(h-70)/3),g=8,ax=w/2+30,top=20;for(int i=0;i<5;i++){Unit u=units.get(i);int col=u.cell%3,row=u.cell/3;RectF rr=new RectF(ax+col*(s+g),top+row*(s+g),ax+col*(s+g)+s,top+row*(s+g)+s);if(rr.contains(e.getX(),e.getY())){selectedCard=i;message=names[i]+"を選択中。写真変更で画像を変えられるよ";invalidate();return true;}}return true;}
        void nextTurn(){ArrayList<Unit> order=new ArrayList<>(units);Collections.sort(order,(a,b)->Boolean.compare(!a.ally,!b.ally));for(Unit u:order){if(u.hp<=0)continue;Unit t=findTarget(u.ally);if(t!=null){t.hp-=u.atk;message=u.name+"の攻撃！ "+t.name+"に"+u.atk+"ダメージ";break;}}units.removeIf(u->u.hp<=0);turn++; boolean allyAlive=false,enemyAlive=false;for(Unit u:units){if(u.ally)allyAlive=true;else enemyAlive=true;}if(!enemyAlive)message="勝利！ 推し軍団の勝ち！"; if(!allyAlive)message="敗北……RESETで再挑戦！";invalidate();}
        Unit findTarget(boolean ally){for(Unit u:units)if(u.ally!=ally&&u.hp>0)return u;return null;}
    }
}
