package com.example.vtubercard;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.graphics.*;
import android.content.Context;
import android.content.res.Resources;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(new BattleView(this)); }

    static class BattleView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Random rnd = new Random();
        Bitmap sheet;
        Unit[] grid = new Unit[9];
        ArrayList<Card> hand = new ArrayList<>();
        RectF[] cells = new RectF[9];
        RectF[] cardRects = new RectF[5];
        RectF battleBtn, resetBtn;
        int selected = -1, turn = 1, playerBase = 120, cpuBase = 120;
        String log = "カードを選んで3x3マスに配置してね！5体まで出せるよ";
        ArrayList<FX> fx = new ArrayList<>();
        long start = System.currentTimeMillis();

        BattleView(Context c){
            super(c); setFocusable(true); setBackgroundColor(Color.rgb(23,6,35));
            sheet = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("vtuber_sheet","drawable",c.getPackageName()));
            resetGame();
        }

        void resetGame(){
            Arrays.fill(grid, null); hand.clear(); fx.clear(); turn=1; playerBase=120; cpuBase=120; selected=-1;
            hand.add(new Card("紫月", 42, 16, "狐火"));
            hand.add(new Card("巫女狐", 36, 13, "回復"));
            hand.add(new Card("尾火", 28, 21, "速攻"));
            hand.add(new Card("白狐", 50, 10, "守護"));
            hand.add(new Card("幻狐", 32, 18, "貫通"));
            placeEnemy(2,new Unit("ゾンビ",32,9,false,"闇"));
            placeEnemy(5,new Unit("骨兵",26,12,false,"骨"));
            placeEnemy(8,new Unit("魔王",55,15,false,"魔"));
            log="カードを選んで空きマスに配置！BATTLEでターン開始";
            invalidate();
        }
        void placeEnemy(int i, Unit u){ grid[i]=u; }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(), h=getHeight(); float t=(System.currentTimeMillis()-start)/1000f;
            drawBg(c,w,h,t); drawTitle(c,w); drawTopStatus(c,w); drawBoard(c,w,h,t); drawLog(c,w,h); drawCards(c,w,h); drawButtons(c,w,h); drawFx(c); postInvalidateOnAnimation();
        }

        void drawBg(Canvas c,float w,float h,float t){
            p.setShader(new LinearGradient(0,0,0,h, Color.rgb(45,11,69), Color.rgb(12,5,26), Shader.TileMode.CLAMP)); c.drawRect(0,0,w,h,p); p.setShader(null);
            p.setColor(Color.argb(35,190,90,255));
            for(int i=0;i<12;i++){ float x=(i*71+t*22)%(w+80)-40; float y=dp(65)+(i*49)%Math.max(1,(int)(h-dp(180))); c.drawCircle(x,y,dp(2+i%3),p); }
        }
        void drawTitle(Canvas c,float w){
            p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(sp(24)); p.setColor(Color.WHITE); c.drawText("九尾カードバトル V1",w/2,dp(44),p);
        }
        void drawTopStatus(Canvas c,float w){
            p.setTextSize(sp(15)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.WHITE);
            c.drawText("TURN " + turn, dp(12), dp(75), p);
            drawHpBar(c, dp(12), dp(83), w*0.39f, dp(12), playerBase, 120, Color.rgb(85,210,255));
            p.setTextAlign(Paint.Align.RIGHT); c.drawText("CPU", w-dp(12), dp(75), p);
            drawHpBar(c, w-dp(12)-w*0.39f, dp(83), w*0.39f, dp(12), cpuBase, 120, Color.rgb(255,85,120));
        }
        void drawHpBar(Canvas c,float x,float y,float ww,float hh,int val,int max,int col){
            p.setColor(Color.argb(110,255,255,255)); c.drawRoundRect(new RectF(x,y,x+ww,y+hh),dp(6),dp(6),p);
            p.setColor(col); c.drawRoundRect(new RectF(x,y,x+ww*Math.max(0,val)/(float)max,y+hh),dp(6),dp(6),p);
        }
        void drawBoard(Canvas c,float w,float h,float t){
            float boardTop=dp(110), size=Math.min(w-dp(24), h*0.46f); float left=(w-size)/2f; float cell=size/3f;
            p.setColor(Color.rgb(92,47,70)); c.drawRoundRect(new RectF(left-dp(5),boardTop-dp(5),left+size+dp(5),boardTop+size+dp(5)),dp(12),dp(12),p);
            for(int r=0;r<3;r++) for(int col=0;col<3;col++){
                int i=r*3+col; RectF rf=new RectF(left+col*cell+dp(3), boardTop+r*cell+dp(3), left+(col+1)*cell-dp(3), boardTop+(r+1)*cell-dp(3)); cells[i]=rf;
                p.setColor((r+col)%2==0?Color.rgb(139,79,94):Color.rgb(121,62,86)); c.drawRoundRect(rf,dp(8),dp(8),p);
                Unit u=grid[i]; if(u!=null) drawUnit(c,u,rf,t);
            }
        }
        void drawUnit(Canvas c,Unit u,RectF r,float t){
            float bob=(float)Math.sin(t*3 + u.name.hashCode())*dp(3);
            p.setColor(u.player?Color.rgb(221,186,255):Color.rgb(255,142,142)); c.drawCircle(r.centerX(), r.centerY()-dp(10)+bob, Math.min(r.width(),r.height())*0.28f, p);
            p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(sp(18)); c.drawText(u.icon, r.centerX(), r.centerY()-dp(3)+bob, p);
            p.setTextSize(sp(11)); c.drawText(u.name, r.centerX(), r.bottom-dp(23), p);
            drawHpBar(c,r.left+dp(8),r.bottom-dp(17),r.width()-dp(16),dp(7),u.hp,u.maxHp,u.player?Color.rgb(100,230,255):Color.rgb(255,100,100));
            p.setTextSize(sp(10)); c.drawText("ATK"+u.atk, r.centerX(), r.top+dp(15), p);
        }
        void drawLog(Canvas c,float w,float h){
            float top=h-dp(250); RectF box=new RectF(dp(10),top,w-dp(10),top+dp(70));
            p.setColor(Color.rgb(210,198,218)); c.drawRoundRect(box,dp(10),dp(10),p);
            p.setColor(Color.rgb(45,25,55)); p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(sp(15)); wrap(c,log,box.left+dp(12),box.top+dp(24),box.width()-dp(24),dp(21),2);
        }
        void drawCards(Canvas c,float w,float h){
            float top=h-dp(165), gap=dp(5), left=dp(8), cw=(w-left*2-gap*4)/5f, ch=dp(86);
            for(int i=0;i<5;i++){
                float x=left+i*(cw+gap); RectF r=new RectF(x,top,x+cw,top+ch); cardRects[i]=r; Card card=hand.get(i);
                p.setColor(card.used?Color.rgb(70,65,78):(selected==i?Color.rgb(225,190,255):Color.rgb(244,239,248))); c.drawRoundRect(r,dp(8),dp(8),p);
                p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setColor(Color.rgb(35,20,45)); p.setTextSize(sp(12)); c.drawText(card.name,x+cw/2,top+dp(18),p);
                p.setTextSize(sp(18)); c.drawText(card.icon,x+cw/2,top+dp(42),p);
                p.setTextSize(sp(10)); c.drawText("HP"+card.hp,x+cw/2,top+dp(60),p); c.drawText("ATK"+card.atk,x+cw/2,top+dp(76),p);
            }
        }
        void drawButtons(Canvas c,float w,float h){
            float top=h-dp(68); battleBtn=new RectF(dp(12),top,w*0.62f,top+dp(50)); resetBtn=new RectF(w*0.66f,top,w-dp(12),top+dp(50));
            p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(sp(18)); p.setTextAlign(Paint.Align.CENTER);
            p.setColor(Color.rgb(185,80,255)); c.drawRoundRect(battleBtn,dp(10),dp(10),p); p.setColor(Color.WHITE); c.drawText("BATTLE",battleBtn.centerX(),battleBtn.centerY()+dp(7),p);
            p.setColor(Color.rgb(235,235,238)); c.drawRoundRect(resetBtn,dp(10),dp(10),p); p.setColor(Color.rgb(35,25,45)); c.drawText("RESET",resetBtn.centerX(),resetBtn.centerY()+dp(7),p);
        }
        void drawFx(Canvas c){
            long now=System.currentTimeMillis();
            for(int i=fx.size()-1;i>=0;i--){ FX f=fx.get(i); float age=(now-f.birth)/650f; if(age>1){fx.remove(i);continue;} p.setColor(Color.argb((int)(255*(1-age)),255,230,70)); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(sp(18+18*age)); c.drawText(f.txt,f.x,f.y-dp(30)*age,p); }
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_DOWN) return true; float x=e.getX(), y=e.getY();
            if(battleBtn!=null && battleBtn.contains(x,y)){ doTurn(); return true; }
            if(resetBtn!=null && resetBtn.contains(x,y)){ resetGame(); return true; }
            for(int i=0;i<5;i++) if(cardRects[i]!=null && cardRects[i].contains(x,y) && !hand.get(i).used){ selected=i; log=hand.get(i).name+"を選択中。空きマスをタップ！"; invalidate(); return true; }
            if(selected>=0){ for(int i=0;i<9;i++) if(cells[i]!=null && cells[i].contains(x,y) && grid[i]==null){ Card card=hand.get(selected); card.used=true; grid[i]=new Unit(card.name,card.hp,card.atk,true,card.icon); log=card.name+"を配置したよ！"; selected=-1; invalidate(); return true; } }
            return true;
        }
        void doTurn(){
            int allies=0,enemies=0; for(Unit u:grid){ if(u!=null){ if(u.player) allies++; else enemies++; }}
            if(allies==0){ log="まずは味方カードを配置してね！"; return; }
            if(enemies==0 || cpuBase<=0 || playerBase<=0){ log="RESETで次の対戦へ！"; return; }
            StringBuilder sb=new StringBuilder();
            ArrayList<Unit> order=new ArrayList<>(); for(Unit u:grid) if(u!=null) order.add(u); Collections.shuffle(order,rnd);
            for(Unit u:order){ if(u.hp<=0) continue; int idx=indexOf(u); Unit target=findTarget(u,idx); if(target!=null){ target.hp-=u.atk; addFx(target,"-"+u.atk); sb.append(u.name).append("→").append(target.name).append(" "); } else { if(u.player){ cpuBase-=u.atk; sb.append(u.name).append("がCPUへ"); } else { playerBase-=u.atk; sb.append(u.name).append("が本陣へ"); } }}
            for(int i=0;i<9;i++) if(grid[i]!=null && grid[i].hp<=0){ addFx(grid[i],"撃破"); grid[i]=null; }
            if(turn%2==0 && countEnemies()<5) spawnEnemy();
            turn++; if(cpuBase<=0 || countEnemies()==0) log="勝利！推したちの勝ち！RESETで再戦できるよ"; else if(playerBase<=0) log="敗北……配置を変えて再挑戦！"; else log=sb.toString(); invalidate();
        }
        Unit findTarget(Unit u,int idx){ Unit best=null; int bi=99; for(int i=0;i<9;i++){ Unit v=grid[i]; if(v!=null && v.player!=u.player){ int d=Math.abs(i/3-idx/3)+Math.abs(i%3-idx%3); if(d<bi){bi=d; best=v;} }} return best; }
        int indexOf(Unit u){ for(int i=0;i<9;i++) if(grid[i]==u) return i; return 0; }
        int countEnemies(){ int n=0; for(Unit u:grid) if(u!=null&&!u.player)n++; return n; }
        void spawnEnemy(){ for(int tries=0;tries<9;tries++){ int i=rnd.nextInt(9); if(grid[i]==null){ grid[i]=new Unit("小鬼",22+turn*2,8+turn,false,"鬼"); log="CPUが小鬼を召喚！"; return; } } }
        void addFx(Unit u,String txt){ int i=indexOf(u); if(i>=0 && cells[i]!=null){ FX f=new FX(); f.x=cells[i].centerX(); f.y=cells[i].centerY(); f.txt=txt; f.birth=System.currentTimeMillis(); fx.add(f); } }
        void wrap(Canvas c,String s,float x,float y,float max,float lh,int maxLines){ String line=""; int lines=0; for(String ch:s.split("")){ if(p.measureText(line+ch)>max && line.length()>0){ c.drawText(line,x,y,p); y+=lh; lines++; line=ch; if(lines>=maxLines-1) break; } else line+=ch; } c.drawText(line,x,y,p); }
        int dp(float v){ return (int)(v*Resources.getSystem().getDisplayMetrics().density+0.5f); } float sp(float v){ return v*Resources.getSystem().getDisplayMetrics().scaledDensity; }
        static class Card { String name,icon; int hp,atk; boolean used=false; Card(String n,int h,int a,String ic){name=n;hp=h;atk=a;icon=ic;} }
        static class Unit { String name,icon; int hp,maxHp,atk; boolean player; Unit(String n,int h,int a,boolean p,String ic){name=n;hp=maxHp=h;atk=a;player=p;icon=ic;} }
        static class FX { float x,y; String txt; long birth; }
    }
}
