package com.kokon.vtuberlocked;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    int total = 0, affection = 0, stage = 1, expr = 0;
    ImageView charView, bgView;
    TextView line, totalView, affView, unlockView, commentView, titleView, hintView;
    GridLayout moneyGrid;
    int[] amounts = {240, 1000, 5000, 10000, 50000};
    boolean[] unlocked = {true, true, false, false, false};
    String[] comments = {"Miiちゃん今日もかわいい！", "配信部屋めっちゃ似合ってる", "応援してるよ！"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        build(); updateAll(); startFloat();
    }

    TextView tv(String s, int sp, int c, int style) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(c); v.setTypeface(Typeface.DEFAULT, style);
        v.setPadding(6, 4, 6, 4); return v;
    }

    GradientDrawable round(int color, int strokeColor, int strokeWidth, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(radius);
        if (strokeWidth > 0) g.setStroke(strokeWidth, strokeColor);
        return g;
    }

    public void build() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(20, 0, 28));

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.HORIZONTAL);
        main.setPadding(10, 8, 10, 8);
        root.addView(main, new FrameLayout.LayoutParams(-1, -1));

        // Left 70%: stream screen
        FrameLayout live = new FrameLayout(this);
        main.addView(live, new LinearLayout.LayoutParams(0, -1, 7));
        bgView = new ImageView(this);
        bgView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bgView.setImageResource(getResources().getIdentifier("bg_stream", "drawable", getPackageName()));
        live.addView(bgView, new FrameLayout.LayoutParams(-1, -1));

        charView = new ImageView(this);
        charView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -1);
        cp.gravity = Gravity.CENTER;
        live.addView(charView, cp);
        live.setOnClickListener(v -> { expr = (expr + 1) % 2; reactTap(); });

        TextView liveTxt = tv("● LIVE", 25, Color.WHITE, Typeface.BOLD);
        liveTxt.setShadowLayer(8, 0, 0, Color.BLACK);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        lp.leftMargin = 16; lp.topMargin = 10;
        live.addView(liveTxt, lp);

        TextView tapHint = tv("TAPで表情変更", 13, 0xffffe6ef, Typeface.BOLD);
        tapHint.setShadowLayer(6,0,0,Color.BLACK);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2);
        hp.leftMargin = 16; hp.gravity = Gravity.BOTTOM | Gravity.LEFT; hp.bottomMargin = 12;
        live.addView(tapHint, hp);

        // Right 30%: compact operation panel
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(12, 6, 4, 6);
        main.addView(panel, new LinearLayout.LayoutParams(0, -1, 3));

        titleView = tv("Mii 推しライブ", 20, Color.WHITE, Typeface.BOLD);
        titleView.setGravity(Gravity.CENTER);
        panel.addView(titleView, new LinearLayout.LayoutParams(-1, -2));

        line = tv("Mii：今日も会いに来てくれてありがとう！", 16, Color.WHITE, Typeface.BOLD);
        line.setGravity(Gravity.CENTER);
        line.setBackground(round(0x33100020, 0x55ff5b79, 1, 18));
        panel.addView(line, new LinearLayout.LayoutParams(-1, 0, 1.2f));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.VERTICAL);
        stats.setPadding(2, 2, 2, 2);
        totalView = tv("", 15, Color.WHITE, Typeface.BOLD);
        affView = tv("", 15, Color.WHITE, Typeface.BOLD);
        unlockView = tv("", 11, 0xffffd6e2, Typeface.BOLD);
        stats.addView(totalView); stats.addView(affView); stats.addView(unlockView);
        panel.addView(stats, new LinearLayout.LayoutParams(-1, 0, 1.0f));

        commentView = tv("", 12, 0xff26142f, Typeface.NORMAL);
        commentView.setBackground(round(0xeef2e8f5, 0, 0, 16));
        panel.addView(commentView, new LinearLayout.LayoutParams(-1, 0, 1.15f));

        hintView = tv("投げ銭", 13, 0xffffd6e2, Typeface.BOLD);
        hintView.setGravity(Gravity.CENTER);
        panel.addView(hintView, new LinearLayout.LayoutParams(-1, -2));

        moneyGrid = new GridLayout(this);
        moneyGrid.setColumnCount(2);
        moneyGrid.setRowCount(3);
        moneyGrid.setPadding(0, 2, 0, 2);
        panel.addView(moneyGrid, new LinearLayout.LayoutParams(-1, 0, 1.45f));

        Button reset = new Button(this);
        reset.setText("RESET"); reset.setTextSize(11); reset.setAllCaps(false);
        reset.setPadding(4, 0, 4, 0);
        reset.setOnClickListener(v -> { total=0; affection=0; stage=1; expr=0; Arrays.fill(unlocked,false); unlocked[0]=unlocked[1]=true; updateAll(); });
        panel.addView(reset, new LinearLayout.LayoutParams(-1, 34));

        setContentView(root);
    }

    void makeButtons() {
        moneyGrid.removeAllViews();
        for (int i = 0; i < amounts.length; i++) {
            final int a = amounts[i];
            Button bt = new Button(this);
            bt.setText(unlocked[i] ? "￥" + NumberFormat.getNumberInstance().format(a) : "🔒￥" + NumberFormat.getNumberInstance().format(a));
            bt.setEnabled(unlocked[i]);
            bt.setTextSize(11);
            bt.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            bt.setAllCaps(false);
            bt.setSingleLine(true);
            bt.setPadding(2, 0, 2, 0);
            bt.setBackground(round(unlocked[i] ? 0xfff7f0fb : 0xff8b7f90, unlocked[i] ? 0xffff5b79 : 0xff5a5060, 2, 16));
            bt.setTextColor(unlocked[i] ? 0xff26142f : 0xff342b38);
            bt.setOnClickListener(v -> donate(a));
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0; gp.height = 44;
            gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            gp.setMargins(3, 3, 3, 3);
            moneyGrid.addView(bt, gp);
        }
    }

    void donate(int a) {
        total += a; affection += Math.max(1, a / 120);
        line.setText("Mii：￥" + NumberFormat.getNumberInstance().format(a) + "ありがとう！もっと頑張るね！");
        addComment("あなた：￥" + NumberFormat.getNumberInstance().format(a) + " 応援するよ！");
        checkUnlock(); pulse(charView); updateAll();
    }

    void checkUnlock() {
        int old = stage;
        if (total >= 10000) { unlocked[3] = true; stage = 3; }
        else if (total >= 5000) { unlocked[2] = true; stage = 2; }
        if (total >= 50000) unlocked[4] = true;
        if (stage > old) unlockEffect();
    }

    void unlockEffect() {
        line.setText(stage == 2 ? "Mii：新しい姿、見せちゃうね…！" : "Mii：ここまで応援してくれたんだね…♡");
        final TextView flash = tv("STAGE UP!", 40, 0xffffd1e6, Typeface.BOLD);
        flash.setGravity(Gravity.CENTER); flash.setShadowLayer(12,0,0,0xffff2d80);
        addContentView(flash, new ViewGroup.LayoutParams(-1, -1));
        AlphaAnimation aa = new AlphaAnimation(1, 0); aa.setDuration(1500);
        aa.setAnimationListener(new Animation.AnimationListener(){ public void onAnimationStart(Animation a){} public void onAnimationRepeat(Animation a){} public void onAnimationEnd(Animation a){ ((ViewGroup)flash.getParent()).removeView(flash); }});
        flash.startAnimation(aa);
    }

    void reactTap() {
        if (stage == 1) line.setText(expr == 1 ? "Mii：ふふ、見つめすぎだよ…？" : "Mii：今日も会いに来てくれてありがとう！");
        else line.setText(stage == 2 ? "Mii：この姿、どうかな…？" : "Mii：もっと近くで見ててね");
        updateImage(); pulse(charView);
    }

    void updateAll() {
        checkUnlock(); updateImage(); makeButtons();
        totalView.setText("累計：￥" + NumberFormat.getNumberInstance().format(total));
        affView.setText("好感度：" + affection);
        unlockView.setText("解放：￥240 / ￥1,000" + (unlocked[2]?" / ￥5,000":" / 🔒￥5,000") + (unlocked[3]?" / ￥10,000":" / 🔒￥10,000") + (unlocked[4]?" / ￥50,000":" / 🔒￥50,000"));
        commentView.setText("コメント\n・" + String.join("\n・", comments));
    }

    void updateImage() {
        String name = "stage1_idle";
        if (stage == 1 && expr == 1) name = "stage1_blush";
        else if (stage == 2) name = "stage2_idle";
        else if (stage >= 3) name = "stage3_idle";
        charView.setImageResource(getResources().getIdentifier(name, "drawable", getPackageName()));
    }

    void addComment(String s) {
        ArrayList<String> list = new ArrayList<>(); list.add(s);
        for (String c : comments) list.add(c);
        while (list.size() > 4) list.remove(list.size() - 1);
        comments = list.toArray(new String[0]);
    }

    void pulse(View v) {
        ScaleAnimation s = new ScaleAnimation(1f,1.035f,1f,1.035f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f);
        s.setDuration(170); s.setRepeatCount(1); s.setRepeatMode(Animation.REVERSE); v.startAnimation(s);
    }

    void startFloat() {
        TranslateAnimation t = new TranslateAnimation(0,0,-5,5);
        t.setDuration(1800); t.setRepeatCount(Animation.INFINITE); t.setRepeatMode(Animation.REVERSE); charView.startAnimation(t);
    }
}
